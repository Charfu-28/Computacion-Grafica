import math
a=3
print (math.sqrt(a))
b=45
print (math.sin(b))
