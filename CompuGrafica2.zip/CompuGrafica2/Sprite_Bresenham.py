import pygame
import random
#===================================================================================================
ALTO = 600
ANCHO = 600
ROJO = (255,0,0)
BLANCO = (255,255,255)
AZUL = (0,0,255)
VERDE = (0, 255, 0)
NEGRO = (0,0,0)
#===================================================================================================
def Bresenham(start, end):
    # Setup initial conditions
    x1, y1 = start
    x2, y2 = end
    dx = x2 - x1
    dy = y2 - y1
    # Determine how steep the line is
    is_steep = abs(dy) > abs(dx)
    # Rotate line
    if is_steep:
        x1, y1 = y1, x1
        x2, y2 = y2, x2
    # Swap start and end points if necessary and store swap state
    swapped = False
    if x1 > x2:
        x1, x2 = x2, x1
        y1, y2 = y2, y1
        swapped = True
    # Recalculate differentials
    dx = x2 - x1
    dy = y2 - y1
    # Calculate error
    error = int(dx / 2.0)
    ystep = 1 if y1 < y2 else -1
    # Iterate over bounding box generating points between start and end
    y = y1
    points = []
    for x in range(x1, x2 + 1):
        coord = (y, x) if is_steep else (x, y)
        points.append(coord)
        error -= abs(dy)
        if error < 0:
            y += ystep
            error += dx
    # Reverse the list if the coordinates were swapped
    if swapped:
        points.reverse()
    return points
#===================================================================================================
class Jugador(pygame.sprite.Sprite):
    def __init__ (self, m):
        pygame.sprite.Sprite.__init__(self)
        self.m=m
        self.dir=0
        self.x=0
        self.image = m[self.x+6][self.dir]
        self.rect = self.image.get_rect()
        self.var_x=0
        self.var_y=0
    def update(self):
        if self.x < 2:
            self.x+=1
        else:
            self.x=0
        self.image = m[self.x+6][self.dir]
        self.rect.x+=self.var_x
        self.rect.y+=self.var_y
#======================================FUNCION PARA RECORTAR========================================
def matriz (archivo, Cant_x, Cant_y):
    matriz = []
    columna = []
    imagen = pygame.image.load(archivo).convert_alpha()
    ancho_img,alto_img = imagen.get_size()
    factor_y=alto_img/Cant_y
    factor_x=ancho_img/Cant_x
    for i in range (Cant_x):
        columna = []
        for j in range (Cant_y):
            cuadro = (i*factor_x,j*factor_y,32,32)
            recorte = imagen.subsurface(cuadro)
            columna.append(recorte)
        matriz.append(columna)
    return matriz
#===================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla = pygame.display.set_mode([ANCHO, ALTO])
    m=matriz('animales.png',12,8)
    jp = Jugador(m)
    general = pygame.sprite.Group()
    general.add(jp)
    jp.rect.x = 100
    jp.rect.y = 330
    reloj = pygame.time.Clock()
    fin = False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    jp.var_x=5
                    jp.var_y=0
                    jp.dir=2
                if event.key == pygame.K_LEFT:
                    jp.var_x=-5
                    jp.var_y=0
                    jp.dir=1
                if event.key == pygame.K_DOWN:
                    jp.var_x=0
                    jp.var_y=5
                    jp.dir=0
                if event.key == pygame.K_UP:
                    jp.var_x=0
                    jp.var_y=-5
                    jp.dir=3
            if event.type  == pygame.KEYUP:
                jp.var_y=0
                jp.var_x=0
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos =  pygame.mouse.get_pos()
                a = [jp.rect.x, jp.rect.y]
                camino = Bresenham(a,pos)
                tam = len(camino)
                i=0
                print(str(jp.rect.x) + "," + str(jp.rect.y))
                for i in range (tam-20):
                    jp.var_x = camino[i][0]-jp.rect.x
                    jp.var_y= camino[i][1]-jp.rect.y
                    if jp.var_x > 0:
                        jp.dir=2
                    elif jp.var_x< 0:
                        jp.dir=1
                    jp.update()
                    pantalla.fill((NEGRO))
                    general.draw(pantalla)
                    pygame.display.flip()
                    reloj.tick(15)
                    i+=20
                jp.var_x=0
                jp.var_y=0
                jp.dir=0
            if event.type == pygame.QUIT:
                fin = True
#===================================================================================================
        general.update()
        pantalla.fill(NEGRO)
        general.draw(pantalla)
        pygame.display.flip()
        reloj.tick(10)
