import pygame
import math
ALTO=600
ANCHO=800
ROJO = (255,0,0)
VERDE = (0,255,0)
AZUL = (0,0,255)
BLANCO = (255,255,255)
NEGRO = (0,0,0)
#================================================================================================
def Bresenham (x0, y0, x1, y1):
    dx = x1-x0
    dy = y1-y0
    if dy < 0:
        dy = -dy
        recorridoy = -1
    else:
        recorridoy = 1
    if dx < 0:
        dx = -dx
        recorridox = -1
    else:
        recorridox = 1
    x = x0
    y = y0    
    if dx > dy:
        p = 2 * dy - dx
        incE = 2*dy
        incNE = 2*(dy-dx)
        while (x != x1):
            x = x + recorridox
            if (p < 0):
                 p = p + incE
            else:
                y = y + recorridoy
                p = p + incNE
            print (x,y)
    else:
        p = 2*dx - dy
        incE = 2*dx
        incNE = 2*(dx-dy)
        while (y != y1):
            y = y + recorridoy
            if (p < 0):
                p = p + incE
            else:
                x = x + recorridox
                p = p + incNE
            print (x,y)
#================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    pantalla.fill(NEGRO)
    Bresenham(25,15,35,23)
    pygame.display.flip()
    fin=False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin=True
