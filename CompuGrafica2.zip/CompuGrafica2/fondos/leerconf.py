import configparser
import pygame
#====================================================================================================
NEGRO    = (   0,   0,   0)
BLANCO   = ( 255, 255, 255)
AZUL     = (   0,   0, 255)
ROJO     = ( 255,   0,   0)
VERDE    = (   0, 255,   0)
#====================================================================================================
ANCHO = 800
ALTO  = 600
#====================================================================================================
def recorte (archivo, Cant_x, Cant_y):
    matriz = []
    columna = []
    imagen = pygame.image.load(archivo).convert_alpha()
    ancho_img,alto_img = imagen.get_size()
    factor_y=alto_img/Cant_y
    factor_x=ancho_img/Cant_x
    for i in range (Cant_x):
        columna = []
        for j in range (Cant_y):
            cuadro = (i*factor_x,j*factor_y,32,32)
            recorte = imagen.subsurface(cuadro)
            columna.append(recorte)
        matriz.append(columna)
    return matriz
#====================================================================================================
if __name__=='__main__':
    pygame.init()
    pantalla= pygame.display.set_mode([ANCHO, ALTO])
    pantalla.fill(BLANCO)
    m = recorte("terrenogen.png",32,12)
    interprete = configparser.ConfigParser()
    interprete.read('mapa.map')
    #print (interprete.get('nivel1','mapa'))
    #print (interprete.get('.','ux'))
    dicc={}
    for seccion in interprete.sections():
        #print (seccion)
        #print (interprete.items(seccion))
        descripcion=dict(interprete.items(seccion))
        dicc[seccion]=descripcion
    #print (dicc['&']['nombre'])
    mapa = dicc['nivel1']['mapa']
    lineas = mapa.split('\n')
    #
    print (lineas)
    '''for element in lineas:
        for elem in element:
            if(elem=='.'):
                print (dicc['nivel1']['mapa'])'''
