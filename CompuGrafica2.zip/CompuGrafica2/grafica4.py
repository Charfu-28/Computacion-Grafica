import pygame
import math
#=============================================================================================================================================
ALTO=400
ANCHO=600
ROJO=(255,0,0)
BLANCO=(255,255,255)
#=============================================================================================================================================
def Linea(p,p1,p2):
    L = pygame.draw.line(p,ROJO,p1,p2)
#=============================================================================================================================================
def triangulo1(p,p1,p2,p3):
    pygame.draw.line(p,ROJO,p1,p2)
    pygame.draw.line(p,ROJO,p2,p3)
    pygame.draw.line(p,ROJO,p3,p1)
#=============================================================================================================================================
def triangulo2(p,lsp):
    pygame.draw.line(p,ROJO, lsp[0], lsp[1])
    pygame.draw.line(p,ROJO, lsp[1], lsp[2])
    pygame.draw.line(p,ROJO, lsp[2], lsp[0])
#=============================================================================================================================================
def triangulo3(p,lsp):
    pygame.draw.polygon(p,ROJO,lsp,2)
#=============================================================================================================================================
def cuadrado1(p,pi,l):
    pygame.draw.line(p,ROJO,pi,[pi[0]+l, pi[1]])
    pygame.draw.line(p,ROJO,pi,[pi[0], pi[1]+l])
    pygame.draw.line(p,ROJO,[pi[0]+l,pi[1]+l],[pi[0]+l,pi[1]])
    pygame.draw.line(p,ROJO,[pi[0]+l,pi[1]+l],[pi[0],pi[1]+l])
#=============================================================================================================================================
def cuadrado2(p,pto,l):
    x=pto[0]
    y=pto[1]
    p1=[x+l,y]
    p2=[x+l,y+l]
    p3=[x,y+l]
    ls=[pto,p1,p2,p3]
    pygame.draw.polygon(p,ROJO,ls)
#=============================================================================================================================================
def trianguloEquilatero1(p,pto,l):
    h=((math.sqrt(3)*l)/2)
    pygame.draw.line(p,ROJO,pto,[pto[0]+l,pto[1]])
    pygame.draw.line(p,ROJO,pto,[pto[0]+(l/2),pto[1]-h])
    pygame.draw.line(p,ROJO,[pto[0]+(l/2),pto[1]-h],[pto[0]+l,pto[1]])
    pygame.draw.line(p,ROJO,[pto[0]+(l/2),pto[1]-h],[pto[0],pto[1]])
#=============================================================================================================================================
def trianguloEquilatero2(p,pto,l):
    x=pto[0]
    y=pto[1]
    h=((math.sqrt(3)*l)/2)
    p1=[x+l,y]
    p2=[(x+(l/2)),(y-h)]
    ls=[pto,p1,p2]
    pygame.draw.polygon(p,ROJO,ls)
#=============================================================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    Linea(pantalla,[100,150],[300,250])
    #triangulo1(pantalla,[100,100],[100,200],[200,200])
    #triangulo2(pantalla,[[100,100],[200,200],[200,100]])
    #triangulo3(pantalla,[[100,100],[200,200],[200,100]])
    #cuadrado1(pantalla,[100,100], 100)
    #cuadrado2(pantalla,[100,100],100)
    #trianguloEquilatero1(pantalla,[200,200],200)
    #trianguloEquilatero2(pantalla,[200,200],200)
    pygame.display.flip()
    fin=False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin=True
