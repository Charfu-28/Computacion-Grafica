import pygame
import random
#===================================================================================================================================
ALTO=600
ANCHO=800
ROJO = (255,0,0)
VERDE = (0,255,0)
AZUL = (0,0,255)
BLANCO = (255,255,255)
NEGRO = (0,0,0)
#===================================================================================================================================
class Jugador (pygame.sprite.Sprite):
    def __init__(self ,an, al):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([an, al])
        self.image.fill(ROJO)
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.var_x=0
        self.var_y=0
    def update(self):
        self.rect.x+=self.var_x
        self.rect.y+=self.var_y
#===================================================================================================================================
class Rival (pygame.sprite.Sprite):
    def __init__(self ,an, al):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([an, al])
        self.image.fill(AZUL)
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.var_x=5
        self.var_y=5
    def update(self):
        self.rect.x+=self.var_x
        self.rect.y+=self.var_y
        if self.rect.x>=ANCHO-self.rect.width:
            self.var_x = -5
        elif (self.rect.x <= 0):
            self.var_x = 5
        if self.rect.y>=ALTO-self.rect.height:
            self.var_y = -5
        elif (self.rect.y <= 0):
            self.var_y = 5
#===============================================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    pantalla.fill(NEGRO)
#==============================Aliados==========================================================================================
    Jp = Jugador(50,70)  # creo el Sprite se controlan por grupos
    general = pygame.sprite.Group()
    general.add(Jp)
    Jp.rect.x=100
    Jp.rect.y=100
#================================Enemigos=======================================================================================
    rivales = pygame.sprite.Group()
    n=10
    for i in range(n):
        r=Rival(20,20)
        r.rect.x=random.randrange(10, ANCHO - 20)
        r.rect.y=random.randrange(10, ALTO - 20)
        rivales.add(r)
        general.add(r)
#===============================================================================================================================
    ptos = 0
    reloj = pygame.time.Clock()
    #general.draw(pantalla)
    #pygame.display.flip()
    fin=False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    Jp.var_y=0
                    Jp.var_x=5
                if event.key == pygame.K_LEFT:
                    Jp.var_y=0
                    Jp.var_x=-5
                if event.key == pygame.K_UP:
                    Jp.var_y=-5
                    Jp.var_x=0
                if event.key == pygame.K_DOWN:
                    Jp.var_y=5
                    Jp.var_x=0
                if event.key == pygame.K_SPACE:
                    Jp.var_y=0
                    Jp.var_x=0
            if event.type == pygame.KEYUP:
                Jp.var_y=0
                Jp.var_x=0
            if event.type == pygame.QUIT:
                fin=True
        #Jp.rect.x+=5
        #Jp.rect.y+=5
#===============================================================================================================================

#===============================================================================================================================
        ls_col = pygame.sprite.spritecollide(Jp,rivales, True)
        for elemento in ls_col:
            ptos+=1
            print (ptos)
        Jp.update()
        rivales.update()
        #actualizacion de la pantalla
        pantalla.fill(NEGRO)
        general.draw(pantalla)
        pygame.display.flip()
        reloj.tick(60)
