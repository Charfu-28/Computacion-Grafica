import pygame
import math
from libreriacls import *
#================================================================================================================================
ALTO=480
ANCHO=640
#================================================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    pantalla.fill(NEGRO)
    tux = pygame.image.load ('tux.png')
    fondo = pygame.image.load ('fondo.png')
    var = tux.get_rect()
    print ( 'Ancho: ',var[2])
    pantalla.blit(tux,[100,100])
    pygame.display.flip()
    y = 100
    x = 100
    var_y = 0
    var_x = 0
    reloj = pygame.time.Clock()
    fin=False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin=True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN:
                    #y+=5
                    var_y = 5
                    var_x = 0
                    #reloj.tick(60)
                if event.key == pygame.K_UP:
                    #y-=5
                    var_y = -5
                    var_x = 0
                    #reloj.tick(60)
                if event.key == pygame.K_LEFT:
                    #x-=2
                    var_x = -5
                    var_y = 0
                if event.key == pygame.K_RIGHT:
                    #x+=2
                    var_x = 5
                    var_y = 0
                if event.key == pygame.K_SPACE:
                    var_x = 0
                    var_y = 0
                if event.key == pygame.K_ESCAPE:
                    var_x = var_x
                    var_y = var_y
#================================================================================================================================
        if (y > ALTO - var[3]):
            var_y = 0
            y = ALTO - var[3]
        else:
            y+= var_y
        if (y < 0):
            var_y = 0
            y = 0
        else:
            y+=var_y
        if (x > ANCHO - var[2]):
            var_x = 0
            x = ANCHO - var[2]
        else:
            x+=var_x
        if (x < 0):
            var_x = 0
            x = 0
#================================================================================================================================
        '''if y > ALTO:
            y = 0
        if y < 0:
            y = ALTO
        x+=var_x
        if x > ANCHO:
            x = 0
        if x < 0:
            x = ANCHO'''
        #tux = pygame.image.load ('tux.png')
        #pantalla.fill(NEGRO)
        pantalla.blit(fondo,[0,0])
        pantalla.blit(tux,[x,y])
        pygame.display.flip()
        #y+=5
        #x+=5
        reloj.tick(60)
# Efectos de Sonido scream ogg,sprait 32*32 o 64*64 pul
