import pygame
from libreriacls import *
#===========================================================================================================
ALTO=600
ANCHO=600
#===========================================================================================================

#===========================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla = pygame.display.set_mode([ANCHO,ALTO])
    centro = [300,300]
    plano = Plano(ANCHO,ALTO,centro,pantalla)
    #r = int(input("Ingrese el radio: "))
    r=40
    plano.Punto2(r)
    pygame.display.flip()
    fin=False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    plano.Punto2(r)
                    pygame.display.flip()
                    if r <= 360:
                        r = r+2
                    pygame.display.flip()
                if event.key == pygame.K_DOWN:
                    plano.Punto2(r)
                    pygame.display.flip()
                    if r >= 1:
                        r = r + 2
                    pygame.display.flip()
            if event.type == pygame.QUIT:
                fin=True
