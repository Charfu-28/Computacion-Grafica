import pygame
import random
#===================================================================================================
ALTO = 600
ANCHO = 600
ROJO = (255,0,0)
BLANCO = (255,255,255)
AZUL = (0,0,255)
VERDE = (0, 255, 0)
NEGRO = (0,0,0)
#===================================================================================================
class Jugador(pygame.sprite.Sprite):
    def __init__ (self, m):
        pygame.sprite.Sprite.__init__(self)
        self.m=m
        self.dir=0
        self.x=0
        self.image = m[self.x+0][self.dir+3]
        self.rect = self.image.get_rect()
        self.var_x=0
        self.var_y=0
    def gravedad(self):
        if self.var_y == 0:
            self.var_y = 1
        else:
            self.var_y += 1
    def update(self):
        #self.accion=1, self.con=0,self.pl[]
        self.gravedad()
        if self.x < 2:
            self.x+=1
        else:
            self.x=0
        self.image = m[self.x+0][self.dir+3]
        self.rect.x+=self.var_x
        self.rect.y+=self.var_y

        if self.rect.y > ALTO-80:
            self.rect.y = ALTO-80

        if self.rect.x > ANCHO-70:
            self.rect.x = ANCHO-70

        if self.rect.x < 0:
            self.rect.x = 0
#======================================FUNCION PARA RECORTAR========================================
def matriz (archivo, Cant_x, Cant_y):
    matriz = []
    columna = []
    imagen = pygame.image.load(archivo).convert_alpha()
    ancho_img,alto_img = imagen.get_size()
    factor_y=alto_img/Cant_y
    factor_x=ancho_img/Cant_x
    for i in range (Cant_x):
        columna = []
        for j in range (Cant_y):
            cuadro = (i*factor_x,j*factor_y,70,80)
            recorte = imagen.subsurface(cuadro)
            columna.append(recorte)
        matriz.append(columna)
    return matriz

class plataforma (pygame.sprite.Sprite):
    var_x = 0
    var_y = 0
    def __init__(self,an,al):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([an, al])
        self.image.fill(ROJO)
        self.rect = self.image.get_rect()
#===================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla = pygame.display.set_mode([ANCHO, ALTO])
    m=matriz('ken.png',7,10)
    jp = Jugador(m)
    pl = plataforma(80,80)
    general = pygame.sprite.Group()
    general.add(jp,pl)
    jp.rect.x = 100
    jp.rect.y = 330
    pl.rect.x = 150
    pl.rect.y = 400
    reloj = pygame.time.Clock()
    fin = False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    jp.var_x=5
                    jp.var_y=0
                    jp.dir=0
                if event.key == pygame.K_LEFT:
                    jp.var_x=-5
                    jp.var_y=0
                    jp.dir=0
                if event.key == pygame.K_DOWN:
                    jp.var_x=0
                    jp.var_y=5
                    jp.dir=0
                if event.key == pygame.K_UP:
                    jp.dir=-1
                if event.key == pygame.K_SPACE:
                    jp.var_y = -20
                    #jp.accion = 2
            if event.type  == pygame.KEYUP:
                jp.var_y=0
                jp.var_x=0
                jp.dir = 0
            if event.type == pygame.QUIT:
                fin = True
#===================================================================================================
        general.update()
        pantalla.fill(NEGRO)
        general.draw(pantalla)
        pygame.display.flip()
        reloj.tick(20)
