import pygame
import random
#=====================================================================================================================
ALTO=680
ANCHO=800
ROJO = (255,0,0)
VERDE = (0,255,0)
AZUL = (0,0,255)
BLANCO = (255,255,255)
NEGRO = (0,0,0)
#======================================================================================================================
class Jugador (pygame.sprite.Sprite):
    var_x = 0
    var_y = 0
    def __init__(self,m):
        pygame.sprite.Sprite.__init__(self)
        self.m=m
        self.dir=0
        self.x=0
        self.image = m[self.x+0][self.dir+0]
        self.rect = self.image.get_rect()
    def update(self):
        self.image = m[self.x+0][self.dir+0]
        self.rect.x += self.var_x
        self.rect.y += self.var_y
        if self.rect.x>=ANCHO-self.rect.width:
            self.rect.x=ANCHO - self.rect.width
        elif (self.rect.x <= 0):
            self.var_x = 0
#========================================================================================================================
class Rival (pygame.sprite.Sprite):
    def __init__(self,ri):
        pygame.sprite.Sprite.__init__(self)
        self.ri = ri
        self.dir = 0
        self.x = 2
        self.image = ri[self.x+0][self.dir+0]
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.rect.x = random.randrange (-100,-50)
        self.var_x=4
        self.var_y=0
        self.temporizador = random.randrange (300)
    def update(self):
        if self.temporizador >= 0:
            self.temporizador -= 2
        else:
            self.rect.x += self.var_x
#==========================================================================================================================
class Rival2 (pygame.sprite.Sprite):
    def __init__(self,z):
        pygame.sprite.Sprite.__init__(self)
        self.z = z
        self.dir = 2
        self.x = 2
        self.image = z[self.x+0][self.dir+0]
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.rect.y = random.randrange (-100,-50)
        self.var_x=0
        self.var_y=6
        self.temporizador = random.randrange (300)
    def update(self):
        if self.temporizador >= 0:
            self.temporizador -= 2
        else:
            self.rect.y += self.var_y
#========================================================================================================================
#======================================== RIVALES NIVEL 2 ===============================================================
class Rival3(pygame.sprite.Sprite):
    def __init__(self,ri):
        pygame.sprite.Sprite.__init__(self)
        self.ri = ri
        self.dir = 0
        self.x = 2
        self.image = ri[self.x+0][self.dir+0]
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.rect.x = random.randrange (-100,-50)
        self.var_x=4
        self.var_y=0
        self.temporizador = random.randrange (300)
    def update(self):
        if self.temporizador >= 0:
            self.temporizador -= 2
        else:
            self.rect.x += self.var_x
#==========================================================================================================================
class Rival4(pygame.sprite.Sprite):
    def __init__(self,z):
        pygame.sprite.Sprite.__init__(self)
        self.z = z
        self.dir = 2
        self.x = 2
        self.image = z[self.x+0][self.dir+0]
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.rect.y = random.randrange (-100,-50)
        self.var_x=0
        self.var_y=6
        self.temporizador = random.randrange (300)
    def update(self):
        if self.temporizador >= 0:
            self.temporizador -= 2
        else:
            self.rect.y += self.var_y
#============================================================================================================================
class DivisionPantalla (pygame.sprite.Sprite):
    def __init__(self, an, al):
        pygame.sprite.Sprite.__init__(self)
        self.image=pygame.Surface([an,al])
        self.image.fill(AZUL)
        self.rect = self.image.get_rect()
        self.var_x=0
        self.var_y=0
#===========================================================================================================================
class Vida (pygame.sprite.Sprite):
    def __init__(self, an, al):
        pygame.sprite.Sprite.__init__(self)
        self.image=pygame.Surface([an,al])
        self.image.fill(VERDE)
        self.rect = self.image.get_rect()
        self.var_x=0
        self.var_y=0
#============================================================================================================================
class Proyectil (pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([5, 20])
        self.image.fill(ROJO)
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.var_y =-5
    def update(self):
        self.rect.y+=self.var_y
#======================================FUNCION PARA RECORTAR Rivales 1========================================
def matriz1(archivo, Cant_x, Cant_y):
    matriz = []
    columna = []
    imagen = pygame.image.load(archivo).convert_alpha()
    ancho_img,alto_img = imagen.get_size()
    factor_y=alto_img/Cant_y
    factor_x=ancho_img/Cant_x
    for i in range (Cant_x):
        columna = []
        for j in range (Cant_y):
            cuadro = (i*factor_x,j*factor_y,85,84)
            recorte = imagen.subsurface(cuadro)
            columna.append(recorte)
        matriz.append(columna)
    return matriz
#======================================FUNCION PARA RECORTAR Rivales 2========================================
def matriz2(archivo, Cant_x, Cant_y):
    matriz = []
    columna = []
    imagen = pygame.image.load(archivo).convert_alpha()
    ancho_img,alto_img = imagen.get_size()
    factor_y=alto_img/Cant_y
    factor_x=ancho_img/Cant_x
    for i in range (Cant_x):
        columna = []
        for j in range (Cant_y):
            cuadro = (i*factor_x,j*factor_y,33.6,34)
            recorte = imagen.subsurface(cuadro)
            columna.append(recorte)
        matriz.append(columna)
    return matriz
#======================================FUNCION PARA RECORTAR Jugador ========================================
def matriz3(archivo, Cant_x, Cant_y):
    matriz = []
    columna = []
    imagen = pygame.image.load(archivo).convert_alpha()
    ancho_img,alto_img = imagen.get_size()
    factor_y=alto_img/Cant_y
    factor_x=ancho_img/Cant_x
    for i in range (Cant_x):
        columna = []
        for j in range (Cant_y):
            cuadro = (i*factor_x,j*factor_y,60,45)
            recorte = imagen.subsurface(cuadro)
            columna.append(recorte)
        matriz.append(columna)
    return matriz
#===========================================Main=============================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    pygame.display.set_caption("COMBAT")
    m = matriz3('nave.png',1,1)
    ri = matriz1('dragon1.png',4,2)
    z = matriz2('fuego.png',5,4)
    pantalla.fill(NEGRO)
#============================================Aliados========================================================================
    Jp = Jugador(m)     # creo el Sprite se controlan por grupos
    general = pygame.sprite.Group()
    general2 = pygame.sprite.Group()
    general.add(Jp)
    general2.add(Jp)
    Jp.rect.x=370
    Jp.rect.y=580
#===========================================Enemigos=========================================================================
    rivales = pygame.sprite.Group()
    n=7
    for i in range(n):
        r = Rival(ri)
        #r.rect.x = random.randrange(10, ANCHO - 20)
        #r.rect.y = -150
        r.rect.y = random.randrange(5, 150)
        r.rect.x = (-150)
        rivales.add(r)
        general.add(r)
        general2.add(r)
#===========================================Enemigos2=========================================================================
    rivales2 = pygame.sprite.Group()
    t=10
    for i in range(t):
        r2 = Rival2(z)
        r2.rect.x = random.randrange(10, ANCHO - 20)
        r2.rect.y = -150
        #r.rect.y=random.randrange(10, ALTO - 10)
        rivales2.add(r2)
        general.add(r2)
        general2.add(r2)
#==========================================Linea De Division en X==============================================================
    ln = DivisionPantalla(800,2)
    general.add(ln)
    general2.add(ln)
    ln.rect.x = 0
    ln.rect.y = 620
#==========================================Linea De Division en Y==============================================================
    lny = DivisionPantalla(2,680)
    general.add(lny)
    general2.add(lny)
    lny.rect.x = 800
    lny.rect.y = 0
#==========================================Vidas_Puntos========================================================================
    vidas = pygame.sprite.Group()
    vidas1 = pygame.sprite.Group()
    tempx = 120
    tempy = 632
    tempx1 = 750
    tempy1 = 632
    for i in range(3): #Dibuja Los Cuadros de Vida
        life = Vida (50,10)
        life.rect.x = tempx
        life.rect.y = tempy
        tempy += 15
        vidas.add(life)
        general.add(life)
        general2.add(life)
    for i in range(1): #Dibuja Cuadro de Puntos
        point = Vida(40,40)
        point.rect.x = tempx1
        point.rect.y = tempy1
        vidas1.add(point)
        general.add(point)
        general2.add(point)
#==========================================Balas=============================================================================
    balas = pygame.sprite.Group()
    balas2 = pygame.sprite.Group()
#=========================================Gestion de Eventos=================================================================
    ptos = 3
    acu = 0
    fin_juego = False
    level2 = False
    Continuar = False
    Pausa = False
    reloj = pygame.time.Clock()
    fin = False
    #cicclo del juego
    while not fin:  #Gestion de eventos
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    Jp.var_y=0
                    Jp.var_x=5
                    Jp.dir = 0
                if event.key == pygame.K_LEFT:
                    Jp.var_y=0
                    Jp.var_x=-5
                    Jp.dir = 0
                if event.key == pygame.K_LCTRL:
                    b1 = Proyectil()
                    b1.rect.x = Jp.rect.x + 30
                    b1.rect.y = Jp.rect.y
                    balas.add(b1)
                    balas2.add(b1)
                    general.add(b1)
                    general2.add(b1)
                if event.key == pygame.K_p:
                    Pausa = not Pausa
                if event.key == pygame.K_SPACE:
                    Continuar = not Continuar
            if event.type == pygame.KEYUP:  #Evento cuando la tecla se levenata
                Jp.var_y=0
                Jp.var_x=0
            if event.type == pygame.QUIT:
                fin=True
#=============================================================================================================================
        for b in balas:
            ls_col3 = pygame.sprite.spritecollide(b,rivales,True)
            for e in ls_col3:
                acu+=1
                rivales.remove(e)  #Limpiar Memoria
                balas.remove(b)
                general.remove(b)
                general2.remove(b)
#=============================================================================================================================
        for h in balas2:
            ls_col6 = pygame.sprite.spritecollide(h,rivales2,True)
            for e in ls_col6:
                acu+=1
                rivales2.remove(e)  #Limpiar Memoria
                balas2.remove(h)
                general.remove(h)
                general2.remove(h)
#=============================================================================================================================
        #Gestion de Colision
        for e in vidas:
            ls_col = pygame.sprite.spritecollide(Jp,rivales, True)   #Colision de Jugador Con rival 1
            for elemento in ls_col:
                vidas.remove(e)
                general.remove(e)
                general2.remove(e)
                ptos-=1
                print (ptos)
                for i in range(1,2):
                    r=Rival(ri)
                    r.rect.y = random.randrange(5, 150)
                    r.rect.x = (-150)
                    rivales.add(r)
                    general.add(r)
                    general2.add(r)
#=============================================Rivales 2=========================================================================
        #Gestion de Colision
        for j in vidas:
            ls_col5 = pygame.sprite.spritecollide(Jp,rivales2, True)   #Colision de Jugador Con rivales2
            for element in ls_col5:
                vidas.remove(j)
                general.remove(j)
                general2.remove(j)
                ptos-=1
                print (ptos)
                for i in range(1,2):
                    r2=Rival2(z)
                    r2.rect.x=random.randrange(10,ANCHO - 20)
                    r2.rect.y=(-150)
                    rivales2.add(r2)
                    general.add(r2)
                    general2.add(r2)
#=============================================================================================================================
        ls_col2 = pygame.sprite.spritecollide(lny, rivales, True)      #Colision de Rivales1 Con La Linea en Y
        for elemento in ls_col2:
            for i in range(0,1):
                r = Rival(ri)
                r.rect.y = random.randrange(5, 150)
                r.rect.x = (-150)
                rivales.add(r)
                general.add(r)
                general2.add(r)
#=============================================================================================================================
        ls_col4 = pygame.sprite.spritecollide(ln, rivales2, True)      #Colision de Rivales2 Con La Linea en X
        for elemento in ls_col4:
            for i in range(0,1):
                r2=Rival2(z)
                r2.rect.x=random.randrange(10,ANCHO - 20)
                r2.rect.y=(-150)
                rivales2.add(r2)
                general.add(r2)
                general2.add(r2)
#=============================================================================================================================
        fuente1 = pygame.font.SysFont('Comic Sans MS', 80) #Crea una fuente con tipo y tamaño
        fuente2 = pygame.font.SysFont('Comic Sans MS', 30) #Crea una fuente con tipo y tamaño
#=============================================================================================================================
        if ptos == 0:
            fin_juego = True
        if ptos == 1:
            level2 = True
        #actualizacion de la pantalla
        if not fin_juego and not Pausa:
            general.update()
            pantalla.fill(NEGRO)
            general.draw(pantalla)
            texto1 = fuente2.render("LIVES: ", True, BLANCO)
            pantalla.blit(texto1,[20,640])
            texto5=fuente2.render(str(ptos), True, BLANCO)
            pantalla.blit(texto5,[95,640])
            texto3 = fuente2.render("POINTS: ", True, BLANCO)
            pantalla.blit(texto3,[650,640])
            texto4=fuente2.render(str(acu), True, NEGRO)
            pantalla.blit(texto4,[755,640])
            texto3 = fuente2.render("LEVEL 1", True, BLANCO)
            pantalla.blit(texto3,[360,640])
            pygame.display.flip()
            reloj.tick(60)

        elif Pausa == True:
            texto6 = fuente1.render("JUEGO EN PAUSA", True, BLANCO)
            pantalla.fill(NEGRO)
            pantalla.blit(texto6, [180,360])
            texto1 = fuente2.render("Presione P para Continuar ", True, BLANCO)
            pantalla.blit(texto1,[180,460])
            pygame.display.flip()

        elif level2 == True and not Continuar:
            pantalla.fill(NEGRO)
            texto6 = fuente1.render("NIVEL 2", True, BLANCO)
            pantalla.blit(texto6, [180,360])
            texto1 = fuente2.render("Pulse Espacio para Continuar ", True, BLANCO)
            pantalla.blit(texto1,[180,460])
            pygame.display.flip()

        elif Continuar == True:
            general2.update()
            pantalla.fill(NEGRO)
            general2.draw(pantalla)
            texto1 = fuente2.render("LIVES: ", True, BLANCO)
            pantalla.blit(texto1,[20,640])
            texto5=fuente2.render(str(ptos), True, BLANCO)
            pantalla.blit(texto5,[95,640])
            texto3 = fuente2.render("POINTS: ", True, BLANCO)
            pantalla.blit(texto3,[650,640])
            texto4=fuente2.render(str(acu), True, NEGRO)
            pantalla.blit(texto4,[755,640])
            texto3 = fuente2.render("LEVEL 2", True, BLANCO)
            pantalla.blit(texto3,[360,640])
            pygame.display.flip()
            reloj.tick(60)
        else:
            texto2 = fuente1.render("GAME OVER", True, BLANCO)
            pantalla.fill(NEGRO)
            pantalla.blit(texto2, [240,280])
            pygame.display.flip()
            reloj.tick(60)
