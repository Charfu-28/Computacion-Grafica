#libreria de clases
#contiene los elementos del plano cartensiano

import pygame
import math
'''
K_UP                  up arrow
K_DOWN                down arrow
K_RIGHT               right arrow
K_LEFT 
'''
ROJO = (255,0,0)
BLANCO = (255,255,255)


def escalar_teclas(pantalla, ls):
    pantalla.triangulo(ls)
    fin=False
    while not fin:
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    print("entre")
                    ls = escalar(ls, [1,2])
                    pygame.display.flip()
                    pantalla.triangulo(ls)
                    pygame.display.flip()
                if event.key == pygame.K_DOWN:
                    ls =escalar(ls, [1,0.8])
                    pantalla.triangulo(ls)
                    pygame.display.flip()
                if event.key == pygame.K_LEFT:
                    ls =escalar(ls, [0.8,1])
                    pantalla.triangulo(ls)
                    pygame.display.flip()
                if event.key == pygame.K_RIGHT:
                    ls =escalar(ls, [2,1])
                    pantalla.triangulo(ls)
                    pygame.display.flip()
            if event.type == pygame.QUIT:
                fin = True

                
def mover_teclas (pantalla,ls):
    pantalla.triangulo(ls)
    fin = False
    while not fin:
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    
                    ls = mover(ls, [0,10])
                    pantalla.pantalla.fill(BLANCO)
                    pantalla.ejes()
                    pantalla.triangulo(ls)
                    pygame.display.flip()
                if event.key == pygame.K_DOWN:
                    ls =mover(ls,[0,-10])
                    pantalla.pantalla.fill(BLANCO)
                    pantalla.ejes()
                    pantalla.triangulo(ls)
                    pygame.display.flip()
                if event.key == pygame.K_LEFT:
                    ls =mover(ls, [-10,0])
                    pantalla.pantalla.fill(BLANCO)
                    pantalla.ejes()
                    pantalla.triangulo(ls)
                    pygame.display.flip()
                if event.key == pygame.K_RIGHT:
                    ls =mover(ls, [10,0])
                    pantalla.pantalla.fill(BLANCO)
                    pantalla.ejes()
                    pantalla.triangulo(ls)
                    pygame.display.flip()
            if event.type == pygame.QUIT:
                fin = True

def mover (ls, cant):
    ld = []
    for punto in ls:
        xn = punto[0]+cant[0]
        yn = punto[1]+cant[1]
        ld.append([xn,yn])
    return ld

def clicks (pantalla):
    clicks = 0
    list_p = []
    print("entre")
    fin = False
    while not fin:
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                list_p.append(pos)
                clicks+=1
                print(Pant(pantalla.centro, pos))
            if(clicks==2):
                m = (list_p[1][1]-list_p[0][1])/(list_p[1][0]-list_p[0][0])
                corte = (m*list_p[0][0])+list_p[0][1]
                
                #print("La ecuacion de la recta es y={:.2F}x+{:.2F}".format(m,corte))

                pantalla.Linea(list_p[0],list_p[1])
                clicks=0
                list_p.clear()   
            if event.type == pygame.QUIT:
                    fin=True     


def Pant(centro,pto):
        px = pto[0]-centro[0]
        py = centro[1]-pto[1]
        return[px,py]

def escalar (ls,sx):
    ld = []
    for punto in ls:
        x = punto[0]
        y = punto[1]
        xs = x*sx[0]
        ys = y*sx[1]
        ld.append([xs,ys])
    return ld

def rotacion (lsp, ang):
    ld = []
    for pto in lsp:
        anr = math.radians(ang)
        x = (pto[0]*math.cos(anr)-pto[1]*math.sin(anr))
        y = (pto[0]*math.sin(anr)+pto[1]*math.cos(anr))
        ld.append([x,y])
    return ld

def rotacionPuntoFijo(lsp,ang,ptof):
    ld = []
    for pto1 in lsp:
        pto = [pto1[0]-ptof[0], pto1[1]- ptof[1]]
        anr = math.radians(ang)
        x = (pto[0]*math.cos(anr)-pto[1]*math.sin(anr))
        y = (pto[0]*math.sin(anr)+pto[1]*math.cos(anr))
        x += ptof[0]
        y+= ptof[1]
        ld.append([x,y])
    return ld

def punto_movil(plano, punto):
    plano.Punto(punto)
    x = punto[0]
    y = punto[1]
    reloj=pygame.time.Clock()
    while x<600:
        x+=1
        punto[0]=x
        plano.Punto(punto)
        #pygame.display.flip()
        reloj.tick(20)
    while y<400:
        y+=1
        punto[1]=y
        plano.Punto(punto)
        #pygame.display.flip()
        reloj.tick(20)




def EscalamientoPuntoFijo(ls,ptf,s):
    lsp = []
    for pto in ls:
        x = pto[0] - ptf[0]
        y = pto[1] - ptf[1]
        xp = x * s[0]
        yp = y * s[1]
        xpp = xp + ptf[0]
        ypp = yp + ptf[1]
        lsp.append([xpp,ypp])
    return lsp

def  ToPolar (pto):
    assert pto[0] != 0
    ang = math.atan(pto[1]/pto[0])
    ang = math.degrees(ang)
    mod = math.sqrt(pto[0]**2+pto[1]**2)
    return [ang, mod]

def De_Pol_Cart(r,an):
    rad= an*math.pi/180
    x=int(r*math.cos(rad))
    y=int(r*math.sin(rad))
    return [x, y]
'''
def RotacionPuntoFijo(ls, ang):
    ld = []
    ls2 = []
    ls3 = []
    #A POLARES
    for pto in ls:
        ls2.append(ToPolar(pto))

    #SE ROTA
    for pto in ls2:
        ang1 = pto[1]
        ang2= ang1+ang
        ld.append([pto[0], ang2])
    # A Cartesiano
    for pto in ld:
        ls3.append(De_Pol_Cart(pto[0],pto[1]))

    return ls3
'''



class Plano:
    ancho=0
    alto=0
    centro=[]

    def __init__(self, ancho,alto,centro,pantalla):
        self.ancho=ancho
        self.alto=alto
        self.centro=centro
        self.pantalla=pantalla
        self.ejes()

    def ejes (self):
        cx = self.centro[0]
        cy= self.centro[1]
        pygame.draw.line(self.pantalla,ROJO, [0,cy], [self.ancho,cy])
        pygame.draw.line(self.pantalla,ROJO, [cx,0], [cx,self.alto])

    def Cart (self,pto):
        cx = self.centro[0]
        cy = self.centro[1]
        px = pto[0]
        py = pto[1]
        xp = cx + px
        yp = cy - py
        return [xp,yp]
    def Pant(self, pto):
        px = pto[0]-self.centro[0]
        py = self.centro[1]-pto[1]


    def Punto (self,pos):
        pygame.draw.circle(self.pantalla, ROJO, (pos), 2)


    def Linea (self,pini,pifi):

        pygame.draw.line(self.pantalla, ROJO, self.Cart(pini),self.Cart(pifi), 2)

    def triangulo (self, lsp):
        grosor=5
        self.Linea(lsp[0], lsp[1])
        self.Linea(lsp[1], lsp[2])
        self.Linea(lsp[2], lsp[0])

    def cuadrado (self,punto,lado):
        pygame.draw.line(self.pantalla,ROJO,punto,[punto[0]+lado, punto[1]])
        pygame.draw.line(self.pantala,ROJO,punto,[punto[0], punto[1]+lado])
        pygame.draw.line(self.pantalla,ROJO,[punto[0]+lado, punto[1]+lado],[punto[0]+lado, punto[1]])
        pygame.draw.line(self.pantalla,ROJO,[punto[0]+lado, punto[1]+lado],[punto[0], punto[1]+lado])
    
    def  ToPolar (self, pto):
        ang = math.atan(y/x)
        ang = math.degrees(ang)
        mod = math.sqrt(pto[0]**2+pto[1]**2)
        return [ang, mod]

class Polar(Plano):
    def __init__(self, centro, ancho, alto, pantalla):
        Plano.__init__(self, centro,ancho,alto,pantalla)
    def Pol_Pant(self, r, an):

        rad= an*math.pi/180
        x=int(r*math.cos(rad))
        y=int(r*math.sin(rad))
        return self.Cart([x, y])
    def Pol_Cart(self,r,an):
        rad= an*math.pi/180
        x=int(r*math.cos(rad))
        y=int(r*math.sin(rad))
        return [x, y]