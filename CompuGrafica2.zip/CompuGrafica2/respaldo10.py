import pygame
import random
from random import randint
#=====================================================================================================================
ALTO=680
ANCHO=800
ROJO = (255,0,0)
VERDE = (0,255,0)
AZUL = (0,0,255)
BLANCO = (255,255,255)
NEGRO = (0,0,0)
frecuencia = 60
#======================================================================================================================
class Jugador (pygame.sprite.Sprite):
    var_x = 0
    var_y = 0
    def __init__(self,m):
        pygame.sprite.Sprite.__init__(self)
        self.m=m
        self.dir=3
        self.x=0
        self.image = m[self.x][self.dir]
        self.rect = self.image.get_rect()
    def update(self):
        if self.x < 2:
            self.x+=1
        else:
            self.x=0
        self.image = m[self.x][self.dir]
        self.rect.x += self.var_x
        self.rect.y += self.var_y
        if self.rect.x>=ANCHO-self.rect.width:
            self.rect.x=ANCHO - self.rect.width
        elif self.rect.x <= 0:
            self.var_x = 0
#======================================================================================================================
class Jugador2 (pygame.sprite.Sprite):
    def __init__(self,v):
        pygame.sprite.Sprite.__init__(self)
        self.v=v
        self.dir2=3
        self.x=0
        self.contador_esq=0
        self.image = v[self.x+0][self.dir2+0]
        self.rect = self.image.get_rect()
        self.var_x = 0
        self.var_y = 0
    def update(self):
        if self.x < 2:
            self.x+=1
        else:
            self.x=0
        self.image = v[self.x+0][self.dir2+0]
        self.rect.x += self.var_x
        self.rect.y += self.var_y
        if self.rect.x>=ANCHO-self.rect.width:
            self.rect.x=ANCHO - self.rect.width
        elif self.rect.x <= 0:
            self.var_x = 0
        if self.rect.y>=620-self.rect.height:
            self.rect.y=620 - self.rect.height
        elif self.rect.y <= 350:
            self.var_y = 0
#========================================================================================================================
class Rival(pygame.sprite.Sprite):
    def __init__(self,ri):
        pygame.sprite.Sprite.__init__(self)
        self.ri = ri
        self.dir = 0
        self.x = 0
        self.image = ri[self.x][self.dir]
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.rect.x = random.randint(800,900)
        self.var_x = -5
        self.var_y = 3
        self.rangodisparo = 2
        self.temporizador = random.randrange (300)
    def update(self):
        if(randint(0,140) < self.rangodisparo):
            be = Proyectil2(fu)
            be.rect.x = self.rect.x -30
            be.rect.y = self.rect.y +42
            balasRival.add(be)
            general.add(be)
        if self.rect.x <= 800 and self.rect.x >= 650:
            self.rect.y -= self.var_y
            self.rect.x += self.var_x
        if self.rect.x <= 649 and self.rect.x >= 500:
            self.rect.y += self.var_y
            self.rect.x += self.var_x
        if self.rect.x <= 499 and self.rect.x >= 350:
            self.rect.y -= self.var_y
            self.rect.x += self.var_x
        if self.rect.x <= 349 and self.rect.x >= 200:
            self.rect.y += self.var_y
            self.rect.x += self.var_x
        if self.rect.x <= 199 and self.rect.x >= 50:
            self.rect.y -= self.var_y
            self.rect.x += self.var_x
        if self.rect.x <= 49 and self.rect.x >= 0:
            self.rect.x += self.var_x
            self.rect.y += self.var_y
        if self.rect.y>=180-self.rect.height:
            self.var_y = -1
        if self.rect.y <= 0:
            self.var_y = 1
        if self.temporizador >= 0:
            self.temporizador -= 2
        else:
            self.rect.x += self.var_x
#========================================================================================================================
class Rival2(pygame.sprite.Sprite):
    def __init__(self,z):
        pygame.sprite.Sprite.__init__(self)
        self.z = z
        self.dir = 2
        self.x = 2
        self.image = z[self.x+0][self.dir+0]
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.rect.y = random.randrange (-100,-50)
        self.var_x=4
        self.var_y=1
        self.temporizador = random.randrange (300)
    def update(self):
        if self.rect.y >= 50 and self.rect.y <= 200:
            self.rect.y += self.var_y
            self.rect.x += self.var_x
        if self.rect.y >= 201 and self.rect.y <= 300:
            self.rect.y += self.var_y
            self.rect.x -= self.var_x
        if self.rect.y >= 301 and self.rect.y <= 400:
            self.rect.y += self.var_y
            self.rect.x += self.var_x
        if self.rect.y >= 401 and self.rect.y <= 500:
            self.rect.y += self.var_y
            self.rect.x -= self.var_x
        if self.rect.y >= 501 and self.rect.y <=600:
            self.rect.y += self.var_y
            self.rect.x += self.var_x
        if self.rect.y >= 601 and self.rect.y <= 680:
            self.rect.y += self.var_y
            self.rect.x -= self.var_x
        if self.rect.x>=ANCHO-self.rect.width:
            self.rect.x=ANCHO - self.rect.width
        elif self.rect.x <= 0:
            self.var_x = 0
        if self.temporizador >= 0:
            self.temporizador -= 2
        else:
            self.rect.y += self.var_y
#========================================================================================================================
class Jefe1(pygame.sprite.Sprite): #JEFE
    def __init__(self,je):
        pygame.sprite.Sprite.__init__(self)
        self.je = je
        self.dir = 2
        self.x = 1
        self.image = je[self.x][self.dir]
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.rect.y = random.randrange (-300,-200)
        self.var_x=3
        self.var_y=1
        self.contador = 0
        self.ciclos=0
        self.t_inicial=30
        self.segundos = 30
        self.rangodisparo = 3
        self.temporizador = random.randrange (300)
    def update(self):
        if self.x < 2:
            self.x+=1
        else:
            self.x=0
        self.image = je[self.x+0][self.dir+0]
        self.rect.x += self.var_x
        self.rect.y += self.var_y
        self.ciclos += 1
        self.segundos = self.t_inicial - self.ciclos//frecuencia
        if self.rect.y >= 10:
            self.var_y = 0
            self.rect.x += self.var_x
        if self.rect.x>=ANCHO-self.rect.width:
            self.var_x = -3
        elif self.rect.x <= 0:
            self.var_x = 3
        if self.temporizador >= 0:
            self.temporizador -= 2
        else:
            self.rect.y += self.var_y
#======================================== RIVALES NIVEL 2 ===============================================================
class Rival3 (pygame.sprite.Sprite):
    def __init__(self,rc):
        pygame.sprite.Sprite.__init__(self)
        self.rc = rc
        self.dir = 0
        self.x = 0
        self.image = rc[self.x+1][self.dir+1]
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.rect.y= random.randint(0,50)
        self.var_y = 1
        self.var_x = 1
        self.rangodisparo = 2
        self.temporizador = random.randrange (300)
    def update(self):
        self.rect.x+=self.var_x
        self.rect.y+=self.var_y
        if self.rect.x>=ANCHO-self.rect.width:
            self.var_x = -2
        elif (self.rect.x <= 0):
            self.var_x = 2
        if self.rect.y>=220-self.rect.height:
            self.var_y = -1
        elif (self.rect.y <= 0):
            self.var_y = 1
        if(randint(0,120) < self.rangodisparo):
            be = Proyectil2(fu)
            be.rect.x = self.rect.x + 5
            be.rect.y = self.rect.y + 10
            balasRival.add(be)
            general2.add(be)
        if self.temporizador >= 0:
            self.temporizador -= 2
        else:
            self.rect.y += self.var_y
#========================================================================================================================
class Rival4(pygame.sprite.Sprite): #JEFE
    def __init__(self,sh):
        pygame.sprite.Sprite.__init__(self)
        self.sh = sh
        self.dir = 0
        self.x = 2
        self.image = sh[self.x+0][self.dir+0]
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.rect.y = random.randrange (-300,-200)
        self.var_x=3
        self.var_y=2
        self.contador = 0
        self.ciclos=0
        self.t_inicial=30
        self.segundos = 30
        self.rangodisparo = 3
        self.temporizador = random.randrange (300)
    def update(self):
        if self.x < 2:
            self.x+=1
        else:
            self.x=0
        self.image = sh[self.x+0][self.dir+0]
        self.rect.x += self.var_x
        self.rect.y += self.var_y
        self.ciclos += 1
        self.segundos = self.t_inicial - self.ciclos//frecuencia
        if self.rect.y >= 10:
            self.var_y = 0
            self.rect.x += self.var_x
        if self.rect.x>=ANCHO-self.rect.width:
            self.var_x = -5
        elif self.rect.x <= 0:
            self.var_x = 5
        if self.temporizador >= 0:
            self.temporizador -= 2
        else:
            self.rect.y += self.var_y
#========================================================================================================================
class DivisionPantalla (pygame.sprite.Sprite):
    def __init__(self, an, al):
        pygame.sprite.Sprite.__init__(self)
        self.image=pygame.Surface([an,al])
        self.image.fill(AZUL)
        self.rect = self.image.get_rect()
        self.var_x=0
        self.var_y=0
#========================================================================================================================
class Vida (pygame.sprite.Sprite):
    def __init__(self, an, al):
        pygame.sprite.Sprite.__init__(self)
        self.image=pygame.Surface([an,al])
        self.image.fill(VERDE)
        self.rect = self.image.get_rect()
        self.var_x=0
        self.var_y=0
#========================================================================================================================
class Vidan (pygame.sprite.Sprite):
    def __init__(self,li):
        pygame.sprite.Sprite.__init__(self)
        self.li=li
        self.dir2=0
        self.x=0
        self.image = li[self.x+0][self.dir2+0]
        self.rect = self.image.get_rect()
        self.var_x=0
        self.var_y=0
#=========================================================================================================================
class Proyectil (pygame.sprite.Sprite):
    def __init__(self,ba):
        pygame.sprite.Sprite.__init__(self)
        self.ba=ba
        self.dir2=0
        self.x=0
        self.image = ba[self.x+0][self.dir2+0]
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.var_y = -7
    def update(self):
        self.rect.y+=self.var_y
#=========================================================================================================================
class Proyectil2 (pygame.sprite.Sprite):
    def __init__(self,fu):
        pygame.sprite.Sprite.__init__(self)
        self.fu=fu
        self.dir2=2
        self.x=0
        self.image = fu[self.x+0][self.dir2+0]
        self.rect = self.image.get_rect()
        self.var_y = 7
    def update(self):
        self.rect.y+=self.var_y
#=========================================================================================================================
class Proyectil3 (pygame.sprite.Sprite):
    def __init__(self,bala):
        pygame.sprite.Sprite.__init__(self)
        self.bala=bala
        self.dir2=0
        self.x=0
        self.image = bala[self.x+0][self.dir2+0]
        self.rect = self.image.get_rect()
        self.var_y = 7
    def update(self):
        self.rect.y+=self.var_y
#======================================FUNCION PARA RECORTAR ============================================================
def Recortar(archivo,an,al):
    imagen = pygame.image.load(archivo).convert_alpha()
    info = imagen.get_size()
    img_ancho = info[0]
    img_alto = info[1]
    corte_x = img_ancho/an
    corte_y = img_alto/al
    m = []
    for i in range (an):
        fila = []
        for j in range (al):
            cuadro = [i*corte_x,j*corte_y,corte_x,corte_y]
            recorte = imagen.subsurface(cuadro)
            fila.append(recorte)
        m.append(fila)
    return m
#===========================================Main===========================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    pygame.display.set_caption("COMBAT")
    ri = Recortar('tt.png',1,1)
    z = Recortar('fuego.png',5,4)
    m = Recortar('navel2.png',3,4)
    rc = Recortar('ken.png',7,10)
    v = Recortar('navel2.png',3,4)
    sh = Recortar('behemot.png',3,4)
    ba = Recortar('bala1.png',1,1)
    li = Recortar('navevida.png',1,1)
    fu = Recortar('baladragon.png',1,3)
    je = Recortar('negro2.png',4,4)
    bala = Recortar('baladr.png',1,1)
    pantalla.fill(NEGRO)
#============================================Aliados========================================================================
    Jp = Jugador(m)     # creo el Sprite se controlan por grupos
    general = pygame.sprite.Group()
    general.add(Jp)
    Jp.rect.x=370
    Jp.rect.y=540
#============================================JUGADOR 2========================================================================
    Jp2 = Jugador2(v)     # creo el Sprite se controlan por grupos
    general2 = pygame.sprite.Group()
    general2.add(Jp2)
    Jp2.rect.x=400
    Jp2.rect.y=418
#===========================================Enemigos1=========================================================================
    rivales = pygame.sprite.Group()
    n=12
    for i in range(n):
        r = Rival(ri)
        r.rect.y = random.randint(20,180)
        r.rect.x = 850
        rivales.add(r)
        general.add(r)
#===========================================Enemigos2=========================================================================
    rivales2 = pygame.sprite.Group()
    t=10
    for i in range(t):
        r2 = Rival2(z)
        r2.rect.x = random.randrange(10, ANCHO - 20)
        r2.rect.y = -150
        rivales2.add(r2)
        general2.add(r2)
#===========================================Enemigos3=========================================================================
    rivales3 = pygame.sprite.Group()
    t=4
    for i in range(t):
        r3 = Rival3(rc)
        r3.rect.x=random.randrange(40, ANCHO - 40)
        r3.rect.y=random.randrange(0, ALTO-460)
        rivales3.add(r3)
        general2.add(r3)
#===========================================EnemigoJefe1=========================================================================
    rivalJefe2 = pygame.sprite.Group()
    r8 = Jefe1(je)
    r8.rect.x = random.randrange(-300,-200)
    r8.rect.y = random.randint(-300,-200)
    rivalJefe2.add(r8)
#===========================================EnemigoJefe2=========================================================================
    rivalJefe = pygame.sprite.Group()
    r5 = Rival4(sh)
    r5.rect.x = random.randrange(10, ANCHO - 20)
    r5.rect.y = -300
    rivalJefe.add(r5)
#==========================================Linea De Division en X==============================================================
    ln = DivisionPantalla(800,2)
    general.add(ln)
    general2.add(ln)
    ln.rect.x = 0
    ln.rect.y = 620
#==========================================Lineas De Division en Y==============================================================
    lny = DivisionPantalla(1,680)
    general.add(lny)
    lny.rect.x = 1
    lny.rect.y = 0
    lny2 = DivisionPantalla(2,680)
    general.add(lny2)
    lny2.rect.x = 799
    lny2.rect.y = 0
#==========================================Vidas_Puntos========================================================================
    vidas = pygame.sprite.Group()
    vidas1 = pygame.sprite.Group()
    vidas2 = pygame.sprite.Group()
    tempx = 120
    tempy = 635
    tempx1 = 742
    tempy1 = 632
    tempx2 = 120
    tempy2 = 635
    for i in range(3):#Dibuja Los Cuadros de Vida nivel 1
        life = Vidan(li)
        life.rect.x = tempx
        life.rect.y = tempy
        tempx += 25
        vidas.add(life)
        general.add(life)
    for p in range(5): #Dibuja Los Cuadros de Vida Nivel 2
        life2 = Vidan(li)
        life2.rect.x = tempx2
        life2.rect.y = tempy2
        tempx2 += 25
        vidas2.add(life2)
        general2.add(life2)
    for i in range(1): #Dibuja Cuadro de Puntos
        point = Vida(50,40)
        point.rect.x = tempx1
        point.rect.y = tempy1
        vidas1.add(point)
        general.add(point)
        general2.add(point)
#==========================================Balas=============================================================================
    balas = pygame.sprite.Group()
    balas2 = pygame.sprite.Group()
    balas3 = pygame.sprite.Group()
    balasRival = pygame.sprite.Group()
#=========================================Gestion de Eventos=================================================================
    ptos = 3
    ptos2 = 5
    acu = 0
    fin_juego = False
    fin_juego2 = False
    level = False
    Continuar = False
    Pausa = False
    Victoria = False
    Inicio = False
    Siguiente = False
    reloj = pygame.time.Clock()
    fin = False
    #ciclo del juego
    while not fin:  #Gestion de eventos
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    Jp.var_y=0
                    Jp.var_x=6
                    Jp2.var_y=0
                    Jp2.var_x=6
                    Jp2.dir2 = 2
                if event.key == pygame.K_LEFT:
                    Jp.var_y=0
                    Jp.var_x=-6
                    Jp2.var_y=0
                    Jp2.var_x=-6
                    Jp2.dir2 = 1
                if event.key == pygame.K_UP:
                    Jp2.var_y=-5
                    Jp2.var_x=0
                    Jp2.dir2 = 3
                if event.key == pygame.K_DOWN:
                    Jp2.var_y=5
                    Jp2.var_x=0
                    Jp2.dir2 = 0
                if event.key == pygame.K_LCTRL:
                    b1 = Proyectil(ba)
                    b1.rect.x = Jp.rect.x + 30
                    b1.rect.y = Jp.rect.y + 5
                    b2 = Proyectil(ba)
                    b2.rect.x = Jp2.rect.x + 30
                    b2.rect.y = Jp2.rect.y + 5
                    balas.add(b1)
                    balas2.add(b1)
                    balas3.add(b2)
                    general.add(b1)
                    general2.add(b2)
                if event.key == pygame.K_p:
                    Pausa = not Pausa
                if event.key == pygame.K_SPACE:
                    Continuar = not Continuar
                if event.key == pygame.K_RETURN:
                    Siguiente = not Siguiente
            if event.type == pygame.KEYUP:  #Evento cuando la tecla se levenata
                Jp.var_y=0
                Jp.var_x=0
                Jp2.var_y=0
                Jp2.var_x=0
                Jp2.dir2 = 3
            if event.type == pygame.QUIT:
                fin=True
#=============================================================================================================================
        for b in balas:
            ls_col3 = pygame.sprite.spritecollide(b,rivales,True)
            for e in ls_col3:
                acu+=1
                rivales.remove(e)
                balas.remove(b)
                general.remove(b)
#=============================================================================================================================
        for h in balas2:
            ls_col6 = pygame.sprite.spritecollide(h,rivales2,False)
            for e in ls_col6:
                balas2.remove(h)
                general2.remove(h)
#============================================Colision balas Jugador1con Rival JEFE1===========================================
        for y in balas:
            ls_col13 = pygame.sprite.spritecollide(y,rivalJefe2,False)
            for e in ls_col13:
                if r8.segundos<=15:
                    e.contador += 1
                    y.kill()
                    if e.contador >= 20:
                        e.kill()
#============================================Colision balas Jugador2 con Rival JEFE2===========================================
        for x in balas3:
            ls_col11 = pygame.sprite.spritecollide(x,rivalJefe,False)
            for e in ls_col11:
                e.contador += 1
                x.kill()
                if e.contador >= 20:
                    e.kill()
#==========================================Colision rivales3 con balas de Jugador 2============================================
        for u in balas3:
            ls_col12 = pygame.sprite.spritecollide(u,rivales3,True)
            for i in ls_col12:
                balas3.remove(u)
                general2.remove(u)
                r3=Rival3(rc)
                r3.rect.x=random.randrange(40, ANCHO - 40)
                r3.rect.y=random.randrange(0, ALTO-460)
                rivales3.add(r3)
                general2.add(r3)
#=========================================#Colision de Jugador2 Con rivales2====================================================
        for j in vidas2:
            ls_col5 = pygame.sprite.spritecollide(Jp2,rivales2, True)
            for element in ls_col5:
                vidas2.remove(j)
                general2.remove(j)
                ptos2-=1
#======================================Colision balas de rival JEFE2 con jugador 2============================================
        for j in vidas2:
            ls_col5 = pygame.sprite.spritecollide(Jp2,balasRival, True)
            for element in ls_col5:
                vidas2.remove(j)
                general2.remove(j)
                ptos2-=1
#======================================Colision balas de rival JEFE1 con jugador 1============================================
        for j in vidas:
            ls_col15 = pygame.sprite.spritecollide(Jp,balasRival, True)
            for element in ls_col15:
                vidas.remove(j)
                general.remove(j)
                ptos-=1
#==========================================Colision de Rivales 1 Con La Linea en Y==========================================
        ls_col2 = pygame.sprite.spritecollide(lny, rivales, True)
        for elemento in ls_col2:
            for i in range(0,1):
                r = Rival(ri)
                r.rect.y = random.randint(20,180)
                r.rect.x = 850
                rivales.add(r)
                general.add(r)
#==========================================Colision de balas enemigas con linea en X==========================================
        ls_col16 = pygame.sprite.spritecollide(ln, balasRival, True)
        for elemento in ls_col16:
            for i in range(0,1):
                balasRival.remove(elemento)
                general.remove(elemento)
#======================================= #Colision de Rivales 2 Con La Linea en X============================================
        ls_col4 = pygame.sprite.spritecollide(ln, rivales2, True)
        for elemento in ls_col4:
            Jp2.contador_esq+=1
            if Jp2.contador_esq%20==0 and Jp2.contador_esq!=0:
                acu+=5
            if elemento.__class__==Rival2:
            for i in range(0,1):
                r2=Rival2(z)
                r2.rect.x=random.randrange(10,ANCHO - 20)
                r2.rect.y=(-150)
                rivales2.add(r2)
                general2.add(r2)
#=============================================================================================================================
        fuente1 = pygame.font.SysFont('Comic Sans MS', 80) #Crea una fuente con tipo y tamaño
        fuente2 = pygame.font.SysFont('Comic Sans MS', 30) #Crea una fuente con tipo y tamaño
#=============================================================================================================================
        if ptos == 0:
            fin_juego = True
        if r8.contador == 20:
            level = True
        if ptos2 == 0:
            fin_juego2 = True
        if r5.contador == 20:
            Victoria = True
        if ptos == 3:
            Inicio = True
        #actualizacion de la pantalla
        if  Inicio == True and not Siguiente:
            pantalla.fill(NEGRO)
            inifon = pygame.image.load ('1.png')
            pantalla.blit(inifon,[0,0])
            texto6 = fuente1.render("Bienvenido", True, BLANCO)
            pantalla.blit(texto6, [280,360])
            texto1 = fuente2.render("Presione Enter para Continuar ", True, BLANCO)
            pantalla.blit(texto1,[380,460])
            pygame.display.flip()
            reloj.tick(60)

        elif not fin_juego and not Pausa and not level and Siguiente:
            general.update()
            rivalJefe2.update()
            pantalla.fill(NEGRO)
            fon = pygame.image.load ('2.png')
            pantalla.blit(fon,[0,0])
            general.draw(pantalla)
            if r8.segundos<=20:
                rivalJefe2.draw(pantalla)
                tex2 = fuente2.render("{} : {}".format(r8.segundos//60,r8.segundos), True, BLANCO)
                pantalla.blit(tex2,[0,0])
                if(randint(0,80) < r8.rangodisparo):
                    jf = Proyectil3(bala)
                    jf.rect.x = r8.rect.x + 172
                    jf.rect.y = r8.rect.y + 132
                    balasRival.add(jf)
                    general.add(jf)
            texto1 = fuente2.render("LIVES: ", True, BLANCO)
            pantalla.blit(texto1,[20,640])
            texto5=fuente2.render(str(ptos), True, BLANCO)
            pantalla.blit(texto5,[95,640])
            texto3 = fuente2.render("POINTS: ", True, BLANCO)
            pantalla.blit(texto3,[650,640])
            texto4=fuente2.render(str(acu), True, NEGRO)
            pantalla.blit(texto4,[747,640])
            texto3 = fuente2.render("LEVEL 1", True, BLANCO)
            pantalla.blit(texto3,[360,640])
            pygame.display.flip()
            reloj.tick(20)
            if r8.segundos<=0:
                fin_juego=True

        elif Pausa == True:
            pantalla.fill(NEGRO)
            pause = pygame.image.load ('pause.png')
            pantalla.blit(pause,[280,100])
            texto6 = fuente1.render("GAME IN PAUSE", True, BLANCO)
            pantalla.blit(texto6,[180,400])
            texto1 = fuente2.render("Press P to continue ", True, BLANCO)
            pantalla.blit(texto1,[290,500])
            pygame.display.flip()
            reloj.tick(60)

        elif level == True and not Continuar:  #Presione espacio para continuar a nivel 2
            pantalla.fill(NEGRO)
            levelc = pygame.image.load ('level.png')
            pantalla.blit(levelc,[208,100])
            textop = fuente2.render("Your current score:", True, BLANCO)
            pantalla.blit(textop,[300,340])
            textopp=fuente2.render(str(acu), True, BLANCO)
            pantalla.blit(textopp,[500,340])
            textoppp = fuente2.render("Press Space to continue ", True, BLANCO)
            pantalla.blit(textoppp,[280,400])
            nextlevel = pygame.image.load ('next.png')
            pantalla.blit(nextlevel,[320,450])
            pygame.display.flip()
            reloj.tick(60)

        elif Continuar == True and not fin_juego2 and not Victoria:         #Pantalla de NIVEL2
            general2.update()
            rivalJefe.update()
            pantalla.fill(NEGRO)
            fondo2 = pygame.image.load ('fn2.png')
            pantalla.blit(fondo2,[0,0])
            general2.draw(pantalla)
            if r5.segundos<=25:
                tex = fuente2.render("{}".format(r5.segundos), True, BLANCO)
                pantalla.blit(tex,[0,0])
                rivalJefe.draw(pantalla)
                if(randint(0,80) < r5.rangodisparo):
                    pj = Proyectil3(bala)
                    pj.rect.x = r5.rect.x + 5
                    pj.rect.y = r5.rect.y + 10
                    balasRival.add(pj)
                    general2.add(pj)
            texto1 = fuente2.render("LIVES: ", True, BLANCO)
            pantalla.blit(texto1,[20,640])
            texto5=fuente2.render(str(ptos2), True, BLANCO)
            pantalla.blit(texto5,[95,640])
            texto3 = fuente2.render("POINTS: ", True, BLANCO)
            pantalla.blit(texto3,[650,640])
            texto4=fuente2.render(str(acu), True, NEGRO)
            pantalla.blit(texto4,[747,640])
            texto3 = fuente2.render("LEVEL 2", True, BLANCO)
            pantalla.blit(texto3,[360,640])
            pygame.display.flip()
            reloj.tick(30)
            if r5.segundos<=0:
                fin_juego2=True

        elif Victoria == True:  #Presione espacio para continuar a nivel 2
            pantalla.fill(NEGRO)
            vic2 = pygame.image.load ('congra.png')
            pantalla.blit(vic2,[100,50])
            vic = pygame.image.load ('winner0.png')
            pantalla.blit(vic,[100,150])
            textop = fuente2.render("SCORE:", True, BLANCO)
            pantalla.blit(textop,[650,650])
            textopp=fuente2.render(str(acu), True, BLANCO)
            pantalla.blit(textopp,[750,650])
            pygame.display.flip()
            reloj.tick(60)
        else:
            pantalla.fill(NEGRO)
            fondo = pygame.image.load ('game1.png')
            pantalla.blit(fondo,[206,200])
            pygame.display.flip()
            reloj.tick(frecuencia)
