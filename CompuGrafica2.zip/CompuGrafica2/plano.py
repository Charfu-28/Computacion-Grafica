import pygame
from libreria import *
#===================================================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    pantalla.fill(NEGRO)
    centro=[300,250]
    ejes(pantalla, centro)
    Punto(pantalla,[20,20])
    Punto(pantalla,transformacion([20,20],centro))
    triangulo(pantalla,transformacion([100,100],centro),transformacion([200,100],centro),transformacion([200,200],centro))
    pygame.display.flip()
    fin=False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin=True
