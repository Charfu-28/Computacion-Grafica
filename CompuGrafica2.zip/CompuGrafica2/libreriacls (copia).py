'''
libreria de clases: libreriacls.py
Contiene clases para plano cartesiano
'''
#===========================================================================================================
import pygame
import math
#=============================================================================================================
ROJO = (255,0,0)
BLANCO = (255,255,255)
NEGRO = (0,0,0)
VERDE = (0,255,0)
AZUL = (30,45,110)
#==============================================================================================================
def Escalamiento(s,pto):
    x=pto[0]*s[0]
    y=pto[1]*s[1]
    return [x,y]
#===============================================================================================================
def Rotacion(pto,an):
    anr=math.radians(an)
    x = (pto[0]*math.cos(anr)-pto[1]*math.sin(anr))
    y = (pto[0]*math.sin(anr)+pto[1]*math.cos(anr))
    return [x,y]
#==============================================================================================================
def EscalamientoPuntoFijo(pto,ptf,s):
    x = pto[0] - ptf[0]
    y = pto[1] - ptf[1]
    xp = x * s[0]
    yp = y * s[1]
    xpp = xp + ptf[0]
    ypp = yp + ptf[1]
    return[xpp,ypp]
#==============================================================================================================
def RotacionPuntoFijo(lsp, ang, ptof):
    ld = []
    for pto1 in lsp:
        pto = [pto1[0]-ptof[0], pto1[1]- ptof[1]]
        anr = math.radians(ang)
        x = (pto[0]*math.cos(anr) - pto[1]*math.sin(anr))
        y = (pto[0]*math.sin(anr) + pto[1]*math.cos(anr))
        x += ptof[0]
        y += ptof[1]
        ld.append([x,y])
    return ld
#=============================================================================================================
def MoverConTeclas(pantalla,lsp):
    pantalla.Triangulo(lsp)
    fin = False
    while not fin:
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    lsp = MoverEnPlano(lsp,[0,5])
                    pantalla.p.fill(NEGRO)
                    pantalla.ejes()
                    pantalla.Triangulo(lsp)
                    pygame.display.flip()
                if event.key == pygame.K_DOWN:
                    lsp =MoverEnPlano(lsp,[0,-5])
                    pantalla.p.fill(NEGRO)
                    pantalla.ejes()
                    pantalla.Triangulo(lsp)
                    pygame.display.flip()
                if event.key == pygame.K_LEFT:
                    lsp =MoverEnPlano(lsp, [-5,0])
                    pantalla.p.fill(NEGRO)
                    pantalla.ejes()
                    pantalla.Triangulo(lsp)
                    pygame.display.flip()
                if event.key == pygame.K_RIGHT:
                    lsp =MoverEnPlano(lsp, [5,0])
                    pantalla.p.fill(NEGRO)
                    pantalla.ejes()
                    pantalla.Triangulo(lsp)
                    pygame.display.flip()
            if event.type == pygame.QUIT:
                fin = True
#==============================================================================================================
def MoverEnPlano(lsp,val):
    ListaAux= []
    for punto in lsp:
        Xm = punto[0] + val[0]
        Ym = punto[1] + val[1]
        ListaAux.append([Xm,Ym])
    return ListaAux
#==============================================================================================================
class Plano:
    ancho=0
    alto=0
    centro=[]

    def __init__(self, an, al, c, pn):
        '''Constructor
        an: ancho de la pantalla
        al: alto de la pantalla
        c: centro
        pn: variable de pantalla
        '''
        self.ancho=an
        self.alto=al
        self.centro=c
        self.p=pn
        self.ejes()

    def ejes(self):
        cx=self.centro[0]
        cy=self.centro[1]
        pygame.draw.line(self.p,ROJO,[0,cy], [self.ancho,cy])
        pygame.draw.line(self.p,ROJO,[cx,0], [cx,self.alto])

    def transformacion(self,pto):
        cx=self.centro[0]
        cy=self.centro[1]
        px = pto[0]
        py = pto[1]
        xp = cx + px
        yp = cy - py
        return[xp, yp]

    def Punto(self,pos):
        pygame.draw.circle(self.p,ROJO,self.transformacion(pos),2)

    def Linea(self,pini,pfin):
        pygame.draw.line(self.p,VERDE,self.transformacion(pini),self.transformacion(pfin))

    def Linea2(self,pini,pfin):
        pygame.draw.line(self.p,AZUL,self.transformacion(pini),self.transformacion(pfin))

    def Triangulo (self, lsp):
        self.Linea(lsp[0], lsp[1])
        self.Linea(lsp[1], lsp[2])
        self.Linea(lsp[2], lsp[0])

    def Cuadrado (self,punto,lado):
        pygame.draw.line(self.pantalla,ROJO,punto,[punto[0]+lado, punto[1]])
        pygame.draw.line(self.pantala,ROJO,punto,[punto[0], punto[1]+lado])
        pygame.draw.line(self.pantalla,ROJO,[punto[0]+lado, punto[1]+lado],[punto[0]+lado, punto[1]])
        pygame.draw.line(self.pantalla,ROJO,[punto[0]+lado, punto[1]+lado],[punto[0], punto[1]+lado])

    def CartPolar(self,pto):
        ang = math.arctan(y/x)
        mod = math.sqrt(p[0]**2 + p[1]**2)
        conver = math.degree(ang)
        return[ang, mod]
#==============================================================================================================
class Polar(Plano):

    def __init__(self, an, al, c, pn):
        Plano.__init__(self, an, al, c, pn)

    def Polar(self, r, an):
        anr = math.radians(an)
        x = int(r*math.cos(anr))
        y = int(r*math.sin(anr))
        return [int(x),int(y)]

    def Punto(self, r, an):
        npto = self.Polar(r, an)
        pygame.draw.circle(self.p,ROJO,self.transformacion(npto),2)

    def Recta (self, r, an):
        npto = self.Polar(r, an)
        self.Linea([0,0], npto)

    def Ecuacion(self,an):
        nt = math.radians(an)
        r = 100 * math.cos(5*nt)
        self.Punto(r,an)
        self.Recta(r,an)
