import pygame
from libreriacls import *
#===================================================================================================================================
ALTO=600
ANCHO=600
#===================================================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    pantalla.fill(NEGRO)
    centro =[300,300]
    plano = Plano(ANCHO,ALTO,centro,pantalla)
    plano.Punto([40,-50])
    plano.Linea([40,-50],[-50,-10])
    pygame.display.flip()
    fin=False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin=True
