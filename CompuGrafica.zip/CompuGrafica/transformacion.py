import pygame
import math
#===================================================================================================================================
ALTO=600
ANCHO=600
ROJO=(255,0,0)
BLANCO=(255,255,255)
NEGRO=(0,0,0)
#===================================================================================================================================
def ejes(p,centro):
    cx=centro[0]
    cy=centro[1]
    pygame.draw.line(p,ROJO,[0,cy], [ANCHO,cy])
    pygame.draw.line(p,ROJO,[cx,0], [cx,ALTO])
#===================================================================================================================================
def Punto(p,pos):
    pygame.draw.circle(p,ROJO,pos,2)
#===================================================================================================================================
def triangulo(p,p1,p2,p3):
    pygame.draw.line(p,ROJO,p1,p2)
    pygame.draw.line(p,ROJO,p2,p3)
    pygame.draw.line(p,ROJO,p3,p1)
#===================================================================================================================================
def transformacion(pto,centro):
    cx=centro[0]
    cy=centro[1]
    px = pto[0]
    py = pto[1]
    xp = cx + px
    yp = cy - py
    return[xp, yp]
#===================================================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    pantalla.fill(NEGRO)
    centro=[300,350]
    ejes(pantalla, centro)
    Punto(pantalla,[20,20])
    Punto(pantalla,transformacion([20,20],centro))
    triangulo(pantalla,transformacion([100,100],centro),transformacion([200,100],centro),transformacion([200,200],centro))
    pygame.display.flip()
    fin=False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin=True
