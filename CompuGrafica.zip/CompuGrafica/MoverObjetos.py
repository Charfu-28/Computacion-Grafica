import pygame
ALTO=400
ANCHO=600
ROJO=(255,0,0)
BLANCO=(255,255,255)
NEGRO=(0,0,0)
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    fin=False
    r1=pygame.Rect(50,50,45,45)
    while not fin:
        pos = pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin=True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    r1.move_ip(-10,0)
                if event.key == pygame.K_RIGHT:
                    r1.move_ip(10,0)
                if event.key == pygame.K_DOWN:
                    r1.move_ip(0,10)
                if event.key == pygame.K_UP:
                    r1.move_ip(0,-10)
            # if event.type == pygame.MOUSEBUTTONDOWN:
            #     r1.move_ip(0,10)
            if event.type == pygame.MOUSEBUTTONUP:
                r1.move_ip(0,-10)
                '''btn = pygame.mouse.get_pressed()
                if btn[0]==1:
                    print ('click izq', pos)'''
        pantalla.fill(NEGRO)
        pygame.draw.rect(pantalla,ROJO,r1)
        pygame.display.update()
