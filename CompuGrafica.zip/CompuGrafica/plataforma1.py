import pygame
#====================================================================================================
NEGRO = (0, 0, 0)
BLANCO = (255, 255, 255)
AZUL = (0, 0, 255)
ROJO = (255, 0, 0)
VERDE = (0, 255, 0)
#====================================================================================================
ANCHO = 800
ALTO = 600
#====================================================================================================
class Jugador(pygame.sprite.Sprite):
    var_x = 0
    var_y = 0
    nivel = None
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        largo = 40
        alto = 60
        self.image = pygame.Surface([largo, alto])
        self.image.fill(ROJO)
        self.rect = self.image.get_rect()
    def update(self):
        self.Gravedad()
        self.rect.x += self.var_x
        lista_impactos_bloques = pygame.sprite.spritecollide(self, self.nivel.listade_plataformas, False)
        for bloque in lista_impactos_bloques:
            # Si nos estamos desplazando hacia la derecha, hacemos que nuestro lado derecho sea el lado izquierdo del objeto que hemos tocado-
            if self.var_x > 0:
                self.rect.right = bloque.rect.left
            elif self.var_x < 0:
                # En caso contrario, si nos desplazamos hacia la izquierda, hacemos lo opuesto.
                self.rect.left = bloque.rect.right

        # Desplazar arriba/abajo
        self.rect.y += self.var_y

        # Comprobamos si hemos chocado contra algo
        lista_impactos_bloques = pygame.sprite.spritecollide(self, self.nivel.listade_plataformas, False)
        for bloque in lista_impactos_bloques:

            # Restablecemos nuestra posición basándonos en la parte superior/inferior del objeto.
            if self.var_y > 0:
                self.rect.bottom = bloque.rect.top
            elif self.var_y < 0:
                self.rect.top = bloque.rect.bottom

            # Detenemos nuestro movimiento vertical
            self.var_y = 0
#====================================================================================================
    def Gravedad(self):
        if self.var_y == 0:
            self.var_y = 1
        else:
            self.var_y += .35
        if self.rect.y >= ALTO - self.rect.height and self.var_y >= 0:
            self.var_y = 0
            self.rect.y = ALTO - self.rect.height
#====================================================================================================
    def saltar(self):
        self.rect.y += 2
        lista_impactos_plataforma = pygame.sprite.spritecollide(self, self.nivel.listade_plataformas, False)
        self.rect.y -= 2
        if len(lista_impactos_plataforma) > 0 or self.rect.bottom >= ALTO:
            self.var_y = -10
#====================================================================================================
class Plataforma(pygame.sprite.Sprite):
    def __init__(self, largo, alto ):
        super().__init__()
        self.image = pygame.Surface([largo, alto])
        self.image.fill(ROJO)
        self.rect = self.image.get_rect()
#====================================================================================================
class Nivel(object):
    """ Esta es una súper clase genérica usada para definir un nivel.
        Crea una clase hija específica para cada nivel con una info específica. """

    def __init__(self, jp):
        """ Constructor. Requerido para cuando las plataformas móviles colisionan con el jp. """
        self.listade_plataformas = pygame.sprite.Group()
        self.listade_enemigos = pygame.sprite.Group()
        self.jp = jp


        # Imagen de fondo
        self.imagende_fondo = None


    # Actualizamos todo en este nivel
    def update(self):
        """ Actualizamos todo en este nivel."""
        self.listade_plataformas.update()
        self.listade_enemigos.update()

    def draw(self, pantalla):
        """ Dibujamos todo en este nivel. """

        # Dibujamos la imagen de fondo
        pantalla.fill(NEGRO)

        # Dibujamos todas las listas de sprites que tengamos
        self.listade_plataformas.draw(pantalla)
        self.listade_enemigos.draw(pantalla)


# Creamos las plataformas para el nivel
class Nivel_01(Nivel):
    """ Definición para el nivel 1. """

    def __init__(self, jp):
        """ Creamos el nivel 1. """

        # llamamos al constructor padre
        Nivel.__init__(self, jp)

        # Array con la información sobre el largo, alto, x, e y
        nivel = [ [210, 70, 500, 500],
                  [210, 70, 200, 400],
                  [210, 70, 600, 300],
                  ]

        # Iteramos sobre el array anterior y añadimos plataformas
        for plataforma in nivel:
            bloque = Plataforma(plataforma[0], plataforma[1])
            bloque.rect.x = plataforma[2]
            bloque.rect.y = plataforma[3]
            bloque.jp = self.jp
            self.listade_plataformas.add(bloque)

def main():
    """ Programa Principal """
    pygame.init()

    # Definimos el alto y largo de la pantalla
    dimensiones = [ANCHO, ALTO]
    pantalla = pygame.display.set_mode(dimensiones)

    pygame.display.set_caption("Saltador de Plataformas")

    # Creamos al jp
    jp = Jugador()

    # Creamos todos los niveles
    listade_niveles = []
    listade_niveles.append(Nivel_01(jp))

    # Establecemos el nivel actual
    nivel_actual_no = 0
    nivel_actual = listade_niveles[nivel_actual_no]

    lista_sprites_activos = pygame.sprite.Group()
    jp.nivel = nivel_actual

    jp.rect.x = 340
    jp.rect.y = ALTO - jp.rect.height
    lista_sprites_activos.add(jp)

    #Iteramos hasta que el usuario pulse sobre el botón de salida
    hecho = False

    # Lo usamos para gestionar cuan rápido se actualiza la pantalla.
    reloj = pygame.time.Clock()

    # -------- Bucle Principal del Programa -----------
    while not hecho:
        for evento in pygame.event.get(): # El usuario realizó alguna acción
            if evento.type == pygame.QUIT: # Si el usuario hizo click en salir
                hecho = True # Marcamos como hecho y salimos de este bucle

            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_LEFT:
                    jp.var_x=-5
                    jp.var_y=0
                if evento.key == pygame.K_RIGHT:
                    jp.var_x=5
                    jp.var_y=0
                if evento.key == pygame.K_UP:
                    jp.saltar()
            if evento.type == pygame.KEYUP:
                if evento.key == pygame.K_LEFT and jp.var_x < 0:
                    jp.var_x=0
                if evento.key == pygame.K_RIGHT and jp.var_x > 0:
                    jp.var_x=0

        # Actualizamos al jp.
        lista_sprites_activos.update()

        # Actualizamos los objetos en este nivel
        nivel_actual.update()

        # Si el jp se aproxima al lado derecho, desplazamos su mundo a la izquierda (-x)
        if jp.rect.right > ANCHO:
            jp.rect.right = ANCHO

        # Si el jp se aproxima al lado izquierdo, desplazamos su mundo a la derecha (+x)
        if jp.rect.left < 0:
            jp.rect.left = 0

        # TODO EL CÓDIGO DE DIBUJO DEBERÍA IR DEBAJO DE ESTE COMENTARIO
        nivel_actual.draw(pantalla)
        lista_sprites_activos.draw(pantalla)

        # TODO EL CÓDIGO DE DIBUJO DEBERÍA IR ENCIMA DE ESTE COMENTARIO

        # Limitamos a 60 fps
        reloj.tick(60)

        # Avanzamos y actualizamos la pantalla con todo lo que hemos dibujado.
        pygame.display.flip()

    # Pórtate bien con el IDLE. Si te olvidas de esta línea, el programa se 'colgará' al salir.
    pygame.quit()

if __name__ == "__main__":
    main()
