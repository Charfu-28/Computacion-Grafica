import pygame
import random
from random import randint
#=====================================================================================================================
ALTO=680
ANCHO=800
ROJO = (255,0,0)
VERDE = (0,255,0)
AZUL = (0,0,255)
BLANCO = (255,255,255)
NEGRO = (0,0,0)
frecuencia = 60
#======================================================================================================================
class Jugador (pygame.sprite.Sprite):
    var_x = 0
    var_y = 0
    def __init__(self,m):
        pygame.sprite.Sprite.__init__(self)
        self.m=m
        self.dir=3
        self.x=0
        self.contador_esq=0
        self.image = m[self.x][self.dir]
        self.rect = self.image.get_rect()
    def update(self):
        if self.x < 2:
            self.x+=1
        else:
            self.x=0
        self.image = m[self.x][self.dir]
        self.rect.x += self.var_x
        self.rect.y += self.var_y
        if self.rect.x>=ANCHO-self.rect.width:
            self.rect.x=ANCHO - self.rect.width
        elif (self.rect.x <= 0):
            self.var_x = 0
#======================================================================================================================
class Jugador2 (pygame.sprite.Sprite):
    def __init__(self,v):
        pygame.sprite.Sprite.__init__(self)
        self.v=v
        self.dir2=3
        self.x=0
        self.image = v[self.x+0][self.dir2+0]
        self.rect = self.image.get_rect()
        self.var_x = 0
        self.var_y = 0
    def update(self):
        if self.x < 2:
            self.x+=1
        else:
            self.x=0
        self.image = v[self.x+0][self.dir2+0]
        self.rect.x += self.var_x
        self.rect.y += self.var_y

        if self.rect.x>=ANCHO-self.rect.width:
            self.rect.x=ANCHO - self.rect.width
        elif (self.rect.x <= 0):
            self.var_x = 0
#========================================================================================================================
class Rival(pygame.sprite.Sprite):
    def __init__(self,ri):
        pygame.sprite.Sprite.__init__(self)
        self.ri = ri
        self.dir = 0
        self.x = 0
        self.image = ri[self.x][self.dir]
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.rect.x = random.randrange (-100,-50)
        self.var_x=2.5
        self.var_y=2.5
        self.rangodisparo = 2
        self.temporizador = random.randrange (300)
    def update(self):
        if(randint(0,50) < self.rangodisparo):
            be = Proyectil2()
            be.rect.x = self.rect.x + 5
            be.rect.y = self.rect.y + 10
            rivales2.add(be)
            general.add(be)
        if self.rect.x >= 0 and self.rect.x <= 100:
            self.rect.y -= self.var_y
            self.rect.x += self.var_x
        if self.rect.x >= 101 and self.rect.x <= 200:
            self.rect.y += self.var_y
            self.rect.x += self.var_x
        if self.rect.x >= 201 and self.rect.x <= 300:
            self.rect.y -= self.var_y
            self.rect.x += self.var_x
        if self.rect.x >= 301 and self.rect.x <= 400:
            self.rect.y += self.var_y
            self.rect.x += self.var_x
        if self.rect.x >= 401 and self.rect.x <=500:
            self.rect.y -= self.var_y
            self.rect.x += self.var_x
        if self.rect.x >= 501 and self.rect.x <= 600:
            self.rect.y += self.var_y
            self.rect.x += self.var_x
        if self.rect.x >= 601 and self.rect.x <= 700:
            self.rect.y -= self.var_y
        if self.temporizador >= 0:
            self.temporizador -= 2
        else:
            self.rect.x += self.var_x
#========================================================================================================================
class Rival2(pygame.sprite.Sprite):
    def __init__(self,z):
        pygame.sprite.Sprite.__init__(self)
        self.z = z
        self.dir = 2
        self.x = 2
        self.image = z[self.x+0][self.dir+0]
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.rect.y = random.randrange (-100,-50)
        self.var_x=4
        self.var_y=1
        self.temporizador = random.randrange (300)
    def update(self):
        if self.rect.y >= 50 and self.rect.y <= 200:
            self.rect.y += self.var_y
            self.rect.x += self.var_x
        if self.rect.y >= 201 and self.rect.y <= 300:
            self.rect.y += self.var_y
            self.rect.x -= self.var_x
        if self.rect.y >= 301 and self.rect.y <= 400:
            self.rect.y += self.var_y
            self.rect.x += self.var_x
        if self.rect.y >= 401 and self.rect.y <= 500:
            self.rect.y += self.var_y
            self.rect.x -= self.var_x
        if self.rect.y >= 501 and self.rect.y <=600:
            self.rect.y += self.var_y
            self.rect.x += self.var_x
        if self.rect.y >= 601 and self.rect.y <= 680:
            self.rect.y += self.var_y
            self.rect.x -= self.var_x
        if self.temporizador >= 0:
            self.temporizador -= 2
        else:
            self.rect.y += self.var_y
#========================================================================================================================
#======================================== RIVALES NIVEL 2 ===============================================================
class Rival3 (pygame.sprite.Sprite):
    def __init__(self,rc):
        pygame.sprite.Sprite.__init__(self)
        self.rc = rc
        self.dir = 0
        self.x = 0
        self.image = rc[self.x+1][self.dir+1]
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.rect.y= random.randrange (-100,-50)
        self.var_y = 1
        self.var_x = 0
        self.rangodisparo = 2
        self.temporizador = random.randrange (300)
    def update(self):
        if(randint(0,50) < self.rangodisparo):
            be = Proyectil2()
            be.rect.x = self.rect.x + 5
            be.rect.y = self.rect.y + 10
            rivales2.add(be)
            general.add(be)
        if self.temporizador >= 0:
            self.temporizador -= 2
        else:
            self.rect.y += self.var_y
#========================================================================================================================
class Rival4(pygame.sprite.Sprite): #JEFE
    def __init__(self,sh):
        pygame.sprite.Sprite.__init__(self)
        self.sh = sh
        self.dir = 0
        self.x = 0
        self.image = sh[self.x+0][self.dir+0]
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.rect.y = random.randrange (-300,-200)
        self.var_x=3
        self.var_y=1
        self.contador = 0
        self.ciclos=0
        self.t_inicial=30
        self.segundos = 30
        self.rangodisparo = 2
        self.temporizador = random.randrange (300)
    def update(self):
        if(randint(0,50) < self.rangodisparo):
            pj = Proyectil2()
            pj.rect.x = self.rect.x + 5
            pj.rect.y = self.rect.y + 10
            rivales2.add(pj)
            general2.add(pj)
        self.rect.y += self.var_y
        self.ciclos += 1
        self.segundos=self.t_inicial-self.ciclos//frecuencia
        if self.rect.y >= 10:
            self.var_y = 0
            self.rect.x += self.var_x

        if self.rect.x>=ANCHO-self.rect.width:
            self.var_x = -5
        elif self.rect.x <= 0:
            self.var_x = 5
        if self.temporizador >= 0:
            self.temporizador -= 2
        else:
            self.rect.y += self.var_y
#========================================================================================================================
class DivisionPantalla (pygame.sprite.Sprite):
    def __init__(self, an, al):
        pygame.sprite.Sprite.__init__(self)
        self.image=pygame.Surface([an,al])
        self.image.fill(AZUL)
        self.rect = self.image.get_rect()
        self.var_x=0
        self.var_y=0
#========================================================================================================================
class DivisionPantalla2 (pygame.sprite.Sprite):
    def __init__(self, an, al):
        pygame.sprite.Sprite.__init__(self)
        self.image=pygame.Surface([an,al])
        self.image.fill(AZUL)
        self.rect = self.image.get_rect()
        self.var_x=0
        self.var_y=0
#========================================================================================================================
class Vida (pygame.sprite.Sprite):
    def __init__(self, an, al):
        pygame.sprite.Sprite.__init__(self)
        self.image=pygame.Surface([an,al])
        self.image.fill(VERDE)
        self.rect = self.image.get_rect()
        self.var_x=0
        self.var_y=0
#=========================================================================================================================
class Proyectil (pygame.sprite.Sprite):
    def __init__(self,ba):
        pygame.sprite.Sprite.__init__(self)
        self.ba=ba
        self.dir2=0
        self.x=0
        self.image = ba[self.x+0][self.dir2+0]
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.var_y =-7
    def update(self):
        self.rect.y+=self.var_y
#=========================================================================================================================
class Proyectil2 (pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([4, 15])
        self.image.fill(AZUL)
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.var_y =5
    def update(self):
        self.rect.y+=self.var_y
#======================================FUNCION PARA RECORTAR Rivales 1========================================
def matriz1(archivo, Cant_x, Cant_y):
    matriz = []
    columna = []
    imagen = pygame.image.load(archivo).convert_alpha()
    ancho_img,alto_img = imagen.get_size()
    factor_y=alto_img/Cant_y
    factor_x=ancho_img/Cant_x
    for i in range (Cant_x):
        columna = []
        for j in range (Cant_y):
            cuadro = (i*factor_x,j*factor_y,85,84)
            recorte = imagen.subsurface(cuadro)
            columna.append(recorte)
        matriz.append(columna)
    return matriz
#======================================FUNCION PARA RECORTAR Rivales 2========================================
def matriz2(archivo, Cant_x, Cant_y):
    matriz = []
    columna = []
    imagen = pygame.image.load(archivo).convert_alpha()
    ancho_img,alto_img = imagen.get_size()
    factor_y=alto_img/Cant_y
    factor_x=ancho_img/Cant_x
    for i in range (Cant_x):
        columna = []
        for j in range (Cant_y):
            cuadro = (i*factor_x,j*factor_y,33.6,34)
            recorte = imagen.subsurface(cuadro)
            columna.append(recorte)
        matriz.append(columna)
    return matriz
#======================================FUNCION PARA RECORTAR Jugador ========================================
def matriz3(archivo, Cant_x, Cant_y):
    matriz = []
    columna = []
    imagen = pygame.image.load(archivo).convert_alpha()
    ancho_img,alto_img = imagen.get_size()
    factor_y=alto_img/Cant_y
    factor_x=ancho_img/Cant_x
    for i in range (Cant_x):
        columna = []
        for j in range (Cant_y):
            cuadro = (i*factor_x,j*factor_y,86.7,82.5)
            recorte = imagen.subsurface(cuadro)
            columna.append(recorte)
        matriz.append(columna)
    return matriz
#======================================FUNCION PARA RECORTAR Rivales 3========================================
def matriz4(archivo, Cant_x, Cant_y):
    matriz = []
    columna = []
    imagen = pygame.image.load(archivo).convert_alpha()
    ancho_img,alto_img = imagen.get_size()
    factor_y=alto_img/Cant_y
    factor_x=ancho_img/Cant_x
    for i in range (Cant_x):
        columna = []
        for j in range (Cant_y):
            cuadro = (i*factor_x,j*factor_y,70,80)
            recorte = imagen.subsurface(cuadro)
            columna.append(recorte)
        matriz.append(columna)
    return matriz
#======================================FUNCION PARA RECORTAR Rivales 3========================================
def matriz5(archivo, Cant_x, Cant_y):
    matriz = []
    columna = []
    imagen = pygame.image.load(archivo).convert_alpha()
    ancho_img,alto_img = imagen.get_size()
    factor_y=alto_img/Cant_y
    factor_x=ancho_img/Cant_x
    for i in range (Cant_x):
        columna = []
        for j in range (Cant_y):
            cuadro = (i*factor_x,j*factor_y,86.7,82.5)
            recorte = imagen.subsurface(cuadro)
            columna.append(recorte)
        matriz.append(columna)
    return matriz
#======================================FUNCION PARA RECORTAR Rivales 4========================================
def matriz6(archivo, Cant_x, Cant_y):
    matriz = []
    columna = []
    imagen = pygame.image.load(archivo).convert_alpha()
    ancho_img,alto_img = imagen.get_size()
    factor_y=alto_img/Cant_y
    factor_x=ancho_img/Cant_x
    for i in range (Cant_x):
        columna = []
        for j in range (Cant_y):
            cuadro = (i*factor_x,j*factor_y,200,200)
            recorte = imagen.subsurface(cuadro)
            columna.append(recorte)
        matriz.append(columna)
    return matriz
#======================================FUNCION PARA RECORTAR bala 1========================================
def matriz7(archivo, Cant_x, Cant_y):
    matriz = []
    columna = []
    imagen = pygame.image.load(archivo).convert_alpha()
    ancho_img,alto_img = imagen.get_size()
    factor_y=alto_img/Cant_y
    factor_x=ancho_img/Cant_x
    for i in range (Cant_x):
        columna = []
        for j in range (Cant_y):
            cuadro = (i*factor_x,j*factor_y,25,35)
            recorte = imagen.subsurface(cuadro)
            columna.append(recorte)
        matriz.append(columna)
    return matriz
#===========================================Main===========================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    pygame.display.set_caption("COMBAT")
    ri = matriz1('dragon1.png',4,2)
    z = matriz2('fuego.png',5,4)
    m = matriz3('navel2.png',3,4)
    rc = matriz4('ken.png',7,10)
    v = matriz5('navel2.png',3,4)
    sh = matriz6('ships.png',1,1)
    ba = matriz7('bala1.png',1,1)
    pantalla.fill(NEGRO)
#============================================Aliados========================================================================
    Jp = Jugador(m)     # creo el Sprite se controlan por grupos
    general = pygame.sprite.Group()
    general.add(Jp)
    Jp.rect.x=370
    Jp.rect.y=540
#============================================JUGADOR 2========================================================================
    Jp2 = Jugador2(v)     # creo el Sprite se controlan por grupos
    general2 = pygame.sprite.Group()
    general2.add(Jp2)
    Jp2.rect.x=400
    Jp2.rect.y=418
#===========================================Enemigos1=========================================================================
    rivales = pygame.sprite.Group()
    n=4
    for i in range(n):
        r = Rival(ri)
        r.rect.y = random.randrange(10, ALTO-500)
        r.rect.x = (-90)
        rivales.add(r)
        general.add(r)
#===========================================Enemigos2=========================================================================
    rivales2 = pygame.sprite.Group()
    t=10
    for i in range(t):
        r2 = Rival2(z)
        r2.rect.x = random.randrange(10, ANCHO - 20)
        r2.rect.y = -150
        rivales2.add(r2)
        general.add(r2)
#===========================================Enemigos3=========================================================================
    rivales3 = pygame.sprite.Group()
    t=2
    for i in range(t):
        r3 = Rival3(rc)
        r3.rect.x=random.randrange(40, ANCHO - 40)
        r3.rect.y=-80
        rivales3.add(r3)
        general2.add(r3)
#===========================================EnemigoJefe=========================================================================
    rivalJefe = pygame.sprite.Group()
    r5 = Rival4(sh)
    r5.rect.x = random.randrange(10, ANCHO - 20)
    r5.rect.y = -300
    rivalJefe.add(r5)
#==========================================Linea De Division en X==============================================================
    ln = DivisionPantalla(800,2)
    general.add(ln)
    general2.add(ln)
    ln.rect.x = 0
    ln.rect.y = 620
#==========================================Linea De Division en X Nivel 2==============================================================
    ln2 = DivisionPantalla2(800,2)
    general2.add(ln2)
    ln2.rect.x = 0
    ln2.rect.y = 220
#==========================================Linea De Division en Y==============================================================
    lny = DivisionPantalla(2,680)
    general.add(lny)
    lny.rect.x = 800
    lny.rect.y = 0
#==========================================Vidas_Puntos========================================================================
    vidas = pygame.sprite.Group()
    vidas1 = pygame.sprite.Group()
    vidas2 = pygame.sprite.Group()
    tempx = 120
    tempy = 632
    tempx1 = 750
    tempy1 = 632
    tempx2 = 120
    tempy2 = 632
    for i in range(3):
        #Dibuja Los Cuadros de Vida
        life = Vida (50,6)
        life.rect.x = tempx
        life.rect.y = tempy
        tempy += 15
        vidas.add(life)
        general.add(life)
    for p in range(5): #Dibuja Los Cuadros de Vida Nivel 2
        life2 = Vida (50,4)
        life2.rect.x = tempx2
        life2.rect.y = tempy2
        tempy2 += 10
        vidas2.add(life2)
        general2.add(life2)
    for i in range(1): #Dibuja Cuadro de Puntos
        point = Vida(40,40)
        point.rect.x = tempx1
        point.rect.y = tempy1
        vidas1.add(point)
        general.add(point)
        general2.add(point)
#==========================================Balas=============================================================================
    balas = pygame.sprite.Group()
    balas2 = pygame.sprite.Group()
    balas3 = pygame.sprite.Group()
#=========================================Gestion de Eventos=================================================================
    ptos = 3
    ptos2 = 5
    paso = 0
    acu = 0
    fin_juego = False
    fin_juego2 = False
    level = False
    Continuar = False
    Pausa = False
    Victoria = False
    Inicio = False
    Siguiente = False
    reloj = pygame.time.Clock()
    fin = False
    #ciclo del juego
    while not fin:  #Gestion de eventos
        if Jp.contador_esq%20==0 and Jp.contador_esq!=0:
            acu+=10
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    Jp.var_y=0
                    Jp.var_x=5
                    Jp2.var_y=0
                    Jp2.var_x=5
                    Jp2.dir2 = 2
                if event.key == pygame.K_LEFT:
                    Jp.var_y=0
                    Jp.var_x=-5
                    Jp2.var_y=0
                    Jp2.var_x=-5
                    Jp2.dir2 = 1
                if event.key == pygame.K_LCTRL:
                    b1 = Proyectil(ba)
                    b1.rect.x = Jp.rect.x + 30
                    b1.rect.y = Jp.rect.y + 5
                    b2 = Proyectil(ba)
                    b2.rect.x = Jp2.rect.x + 30
                    b2.rect.y = Jp2.rect.y + 5
                    balas.add(b1)
                    balas2.add(b1)
                    balas3.add(b2)
                    general.add(b1)
                    general2.add(b2)
                if event.key == pygame.K_p:
                    Pausa = not Pausa
                if event.key == pygame.K_SPACE:
                    Continuar = not Continuar
                if event.key == pygame.K_RETURN:
                    Siguiente = not Siguiente
            if event.type == pygame.KEYUP:  #Evento cuando la tecla se levenata
                Jp.var_y=0
                Jp.var_x=0
                Jp2.var_y=0
                Jp2.var_x=0
                Jp2.dir2 = 3
            if event.type == pygame.QUIT:
                fin=True
#=============================================================================================================================
        for b in balas:
            ls_col3 = pygame.sprite.spritecollide(b,rivales,True)
            for e in ls_col3:
                acu+=1
                rivales.remove(e)  #Limpiar Memoria
                balas.remove(b)
                general.remove(b)
#=============================================================================================================================
        for h in balas2:
            ls_col6 = pygame.sprite.spritecollide(h,rivales2,False)
            for e in ls_col6:
                balas2.remove(h)
                general.remove(h)
#=============================================================================================================================
        '''for u in balas3:
            ls_col8 = pygame.sprite.spritecollide(u,rivales3,True)
            for e in ls_col8:
                acu+=1
                rivales3.remove(e)  #Limpiar Memoria
                balas3.remove(u)
                general2.remove(u)'''
#============================================Colision balas Jugador2 con Rival JEFE===========================================
        for x in balas3:
            ls_col11 = pygame.sprite.spritecollide(x,rivalJefe,False)
            for e in ls_col11:
                e.contador += 1
                x.kill()
                if e.contador >= 20:
                    e.kill()
#==========================================Colision rivales3 con balas de Jugador 2============================================
        for u in balas3:
            ls_col12 = pygame.sprite.spritecollide(u,rivales3,False)
            for i in ls_col12:
                balas3.remove(u)
                r3=Rival3(rc)
                r3.rect.x=random.randrange(40, ANCHO - 40)
                r3.rect.y=random.randrange(0, ALTO-460)
                rivales3.add(r3)
                general2.add(r3)
                general2.remove(u)
#=============================================Rivales 2=========================================================================
        for j in vidas:
            ls_col5 = pygame.sprite.spritecollide(Jp,rivales2, True)   #Colision de Jugador1 Con rivales2
            for element in ls_col5:
                vidas.remove(j)
                general.remove(j)
                ptos-=1
#======================================Colision balas de rival JEFE con jugador 2==============================================
        for j in vidas2:
            ls_col5 = pygame.sprite.spritecollide(Jp2,rivales2, True)
            for element in ls_col5:
                vidas2.remove(j)
                general2.remove(j)
                ptos2-=1
#=============================================================================================================================
        ls_col2 = pygame.sprite.spritecollide(lny, rivales, True)      #Colision de Rivales 1 Con La Linea en Y
        for elemento in ls_col2:
            for i in range(0,1):
                r = Rival(ri)
                r.rect.y = random.randrange(10,ALTO- 500)
                r.rect.x = (-90)
                rivales.add(r)
                general.add(r)
#=============================================================================================================================
        ls_col4 = pygame.sprite.spritecollide(ln, rivales2, True)      #Colision de Rivales 2 Con La Linea en X
        for elemento in ls_col4:
            Jp.contador_esq+=1
            if elemento.__class__==Rival2:
                for i in range(0,1):
                    r2=Rival2(z)
                    r2.rect.x=random.randrange(10,ANCHO - 20)
                    r2.rect.y=(-150)
                    rivales2.add(r2)
                    general.add(r2)
#=============================================================================================================================
        ls_col9 = pygame.sprite.spritecollide(ln2, rivales3, True)      #Colision de Rivales3 Con La Linea en X
        for elemento in ls_col9:
            for i in range(0,1):
                r3=Rival3(rc)
                r3.rect.x=random.randrange(40, ANCHO - 40)
                r3.rect.y=random.randrange(0, ALTO-460)
                rivales3.add(r3)
                general2.add(r3)
#=============================================================================================================================
        fuente1 = pygame.font.SysFont('Comic Sans MS', 80) #Crea una fuente con tipo y tamaño
        fuente2 = pygame.font.SysFont('Comic Sans MS', 30) #Crea una fuente con tipo y tamaño
#=============================================================================================================================
        if ptos == 0:
            fin_juego = True
        if acu == 4:
            level = True
        if ptos2 == 0:
            fin_juego2 = True
        if acu == 6:
            Victoria = True
        if ptos == 3:
            Inicio = True
        #actualizacion de la pantalla
        if  Inicio == True and not Siguiente:
            texto6 = fuente1.render("Bienvenido", True, BLANCO)
            pantalla.fill(NEGRO)
            pantalla.blit(texto6, [180,360])
            texto1 = fuente2.render("Presione Enter para Continuar ", True, BLANCO)
            pantalla.blit(texto1,[180,460])
            pygame.display.flip()

        elif not fin_juego and not Pausa and not level and Siguiente:
            general.update()
            pantalla.fill(NEGRO)
            general.draw(pantalla)
            texto1 = fuente2.render("LIVES: ", True, BLANCO)
            pantalla.blit(texto1,[20,640])
            texto5=fuente2.render(str(ptos), True, BLANCO)
            pantalla.blit(texto5,[95,640])
            texto3 = fuente2.render("POINTS: ", True, BLANCO)
            pantalla.blit(texto3,[650,640])
            texto4=fuente2.render(str(acu), True, NEGRO)
            pantalla.blit(texto4,[755,640])
            texto3 = fuente2.render("LEVEL 1", True, BLANCO)
            pantalla.blit(texto3,[360,640])
            pygame.display.flip()
            reloj.tick(60)

        elif Pausa == True:
            pantalla.fill(NEGRO)
            pause = pygame.image.load ('pause.png')
            pantalla.blit(pause,[280,100])
            texto6 = fuente1.render("GAME IN PAUSE", True, BLANCO)
            pantalla.blit(texto6,[180,400])
            texto1 = fuente2.render("Press P to continue ", True, BLANCO)
            pantalla.blit(texto1,[290,500])
            pygame.display.flip()

        elif level == True and not Continuar:  #Presione espacio para continuar a nivel 2
            pantalla.fill(NEGRO)
            levelc = pygame.image.load ('level.png')
            pantalla.blit(levelc,[208,100])
            textop = fuente2.render("Your current score:", True, BLANCO)
            pantalla.blit(textop,[300,340])
            textopp=fuente2.render(str(acu), True, BLANCO)
            pantalla.blit(textopp,[500,340])
            textoppp = fuente2.render("Press Space to continue ", True, BLANCO)
            pantalla.blit(textoppp,[280,400])
            nextlevel = pygame.image.load ('next.png')
            pantalla.blit(nextlevel,[320,450])
            pygame.display.flip()

        elif Continuar == True and not fin_juego2 and not Victoria:         #Pantalla de NIVEL2
            general2.update()
            rivalJefe.update()
            pantalla.fill(NEGRO)
            general2.draw(pantalla)
            if r5.segundos<=20:
                rivalJefe.draw(pantalla)
                tex = fuente2.render("{}:{} ".format(r5.segundos//60, r5.segundos), True, BLANCO)
                pantalla.blit(tex,[0,0])
            texto1 = fuente2.render("LIVES: ", True, BLANCO)
            pantalla.blit(texto1,[20,640])
            texto5=fuente2.render(str(ptos2), True, BLANCO)
            pantalla.blit(texto5,[95,640])
            texto3 = fuente2.render("POINTS: ", True, BLANCO)
            pantalla.blit(texto3,[650,640])
            texto4=fuente2.render(str(acu), True, NEGRO)
            pantalla.blit(texto4,[755,640])
            texto3 = fuente2.render("LEVEL 2", True, BLANCO)
            pantalla.blit(texto3,[360,640])
            pygame.display.flip()
            reloj.tick(60)
            if r5.segundos<=0:
                fin_juego2=True
        elif Victoria == True:  #Presione espacio para continuar a nivel 2
            pantalla.fill(NEGRO)
            vic2 = pygame.image.load ('congra.png')
            pantalla.blit(vic2,[100,50])
            vic = pygame.image.load ('winner0.png')
            pantalla.blit(vic,[100,150])
            textop = fuente2.render("SCORE:", True, BLANCO)
            pantalla.blit(textop,[650,650])
            textopp=fuente2.render(str(acu), True, BLANCO)
            pantalla.blit(textopp,[750,650])
            pygame.display.flip()
        else:
            pantalla.fill(NEGRO)
            fondo = pygame.image.load ('game1.png')
            pantalla.blit(fondo,[206,200])
            pygame.display.flip()
            reloj.tick(frecuencia)
