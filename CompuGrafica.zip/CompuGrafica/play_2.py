import pygame
ALTO=500
ANCHO=800
ROJO=(255,0,0)
BLANCO=(255,255,255)
NEGRO=(0,0,0)

class Jugador(pygame.sprite.Sprite):
    def __init__(self, img_sprite):
        pygame.sprite.Sprite.__init__(self)
        self.m=img_sprite
        self.image=self.m[0][7]
        self.rect=self.image.get_rect()
        self.dir=0
        self.i=0
        #self.sonido=pygame.mixer.Sound('Wilhelm_Scream.ogg')
        self.var_x=0
        self.var_y=0
        self.muros=None

    def saltar(self):
        self.var_y=-10
        self.sonido.play()

    def gravedad(self):
        if self.var_y==0:
            self.var_y=1
        else:
            self.var_y+=0.35
    def update(self):
        self.gravedad()

        if self.var_x !=0 or self.var_y !=0:
            if self.i <2:
                self.i+=1
            else:
                self.i=0
        self.image=self.m[self.dir][self.i+6]
        #self.rect=self.image.get_rect()
        #MOVIMIENTO LATERAL
        self.rect.x += self.var_x

        ls_muros=pygame.sprite.spritecollide(self, self.muros, False)
        for m in ls_muros:
            if self.var_x>0:
                self.rect.right=m.rect.left
            if self.var_x<0:
                self.rect.left=m.rect.right
        #que no sobrepase dimensiones de pantalla lateralmente
        if self.rect.right>ANCHO:
            self.rect.right=ANCHO
        if self.rect.left<0:
            self.rect.left=0
        #MOVIMIENTO VERTICAL
        self.rect.y += self.var_y
        ls_muros=pygame.sprite.spritecollide(self, self.muros, False)
        for m in ls_muros:
            if self.var_y>0:
                self.rect.bottom=m.rect.top
            if self.var_y<0:
                self.rect.top=m.rect.bottom
            self.var_y=0
        #que no sobrepase dimensiones de pantalla
        if self.rect.bottom>ALTO:
            self.rect.bottom=ALTO
            self.var_y=0
        if self.rect.top<0:
            self.rect.top=0

class Muro(pygame.sprite.Sprite):
    def __init__(self, x, y, an, al):
        pygame.sprite.Sprite.__init__(self)
        self.image=pygame.Surface([an, al])
        self.image.fill(ROJO)
        self.rect=self.image.get_rect()
        self.rect.x=x
        self.rect.y=y


def recortes (imagen, alto, ancho):
    info= fondo.get_size()
    anchito=info[0]/ancho
    altito=info[1]/alto
    matriz=[]
    for fila in range(alto):
        lista_fila=[]
        for columna in range(ancho):
            cuadro=[columna*anchito,fila*altito,anchito,altito]
            recorte=imagen.subsurface(cuadro)
            lista_fila.append(recorte)
        matriz.append(lista_fila)
    return matriz

if __name__=='__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO, ALTO])

    fondo= pygame.image.load('animales.png').convert_alpha()
    anm=recortes(fondo, 8, 12)

    #GRUPOS
    general=pygame.sprite.Group()
    jugadores=pygame.sprite.Group()
    muros=pygame.sprite.Group()

    #JUGADOR
    jp=Jugador(anm)
    general.add(jp)
    jugadores.add(jp)
    '''
    #MUROS
    m=Muro(150, 150, 50, 500)
    muros.add(m)
    general.add(m)

    m=Muro(350, 150, 500, 50)
    muros.add(m)
    general.add(m)


    '''
    m=Muro(150, 400, 500, 50)
    muros.add(m)
    general.add(m)

    m=Muro(400, 200, 500, 50)
    muros.add(m)
    general.add(m)
    jp.muros=muros

    f_con=0
    f_tasa=160
    t_ini=3
    fuente=pygame.font.Font(None, 36)

    fondo=pygame.image.load('fondo.jpg')
    info= fondo.get_size()
    fondo_ancho=info[0]
    fondo_alto=info[1]
    f_x=0

    reloj=pygame.time.Clock()
    fin=False
    finJuego=False
    while not fin:
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                fin=True
        if event.type==pygame.KEYDOWN:
            if event.key==pygame.K_LEFT:
                jp.dir=1
                jp.var_x=-5
                #jp.var_y=0
            if event.key==pygame.K_RIGHT:
                jp.dir=2
                jp.var_x=5
                #jp.var_y=0
            if event.key==pygame.K_UP:
                jp.dir=3
                jp.var_x=0
                jp.var_y=-5
            if event.key==pygame.K_DOWN:
                jp.dir=0
                jp.var_x=0
                jp.var_y=5

            if event.key == pygame.K_SPACE:
                #jp.var_x= 0
                jp.saltar()

        general.update()

        #ciclo de juego


        #cuenta regresiva
        t_segundos=t_ini-(f_con // f_tasa)
        minutos=t_segundos // 60
        segundos=t_segundos % 60
        texto_reloj='{0:02}:{1:02}'.format(minutos, segundos)
        texto=fuente.render(texto_reloj, True, BLANCO)
        if t_segundos<=5:
            texto=fuente.render(texto_reloj, True, ROJO)
        if t_segundos<=0:
            #finJuego=True
            pass

        if finJuego:
            texto=fuente.render('Loser, I am the only chosen one who always wins', True, ROJO)
            pantalla.fill(NEGRO)
            pantalla.blit(texto,[50,50])
            pygame.display.flip()
        else:
            #LIMITES PARA MOVER FONDO A IZQUIERDA O DERECHA
            if jp.rect.x>=ANCHO/2+300-jp.rect.width and f_x+fondo_ancho>ANCHO:
                jp.rect.x=ANCHO/2+300-jp.rect.width
                f_x-=2
            if jp.rect.x<=ANCHO/2-300-jp.rect.width and f_x<0:
                jp.rect.x=ANCHO/2-300-jp.rect.width
                f_x+=2
            pantalla.blit(fondo, [f_x, 0])
            pantalla.blit(texto,[0,0])
            general.draw(pantalla)
            pygame.display.flip()
            f_con+=1
            reloj.tick(f_tasa)
