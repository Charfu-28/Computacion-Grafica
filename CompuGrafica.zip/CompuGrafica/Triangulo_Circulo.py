import pygame
from libreriacls import *
#================================================================================================================================
ALTO=600
ANCHO=600
#================================================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    centro =[300,300]
    plano = Plano(ANCHO,ALTO,centro,pantalla)
    plano.Circulo_Triangulo()
    pygame.display.flip()
    fin=False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin=True
