import pygame
import math
ALTO=600
ANCHO=800
ROJO = (255,0,0)
VERDE = (0,255,0)
AZUL = (0,0,255)
BLANCO = (255,255,255)
NEGRO = (0,0,0)
#================================================================================================
def Bresenham (x0, y0, x1, y1):
    dx = x1-x0
    dy = y1-y0
    if dy >= 0:
        incrementoy = 1
    else:
        dy = -dy
        incrementoy = -1
    if dx >= 0:
        incrementox = 1
    else:
        dx = -dx
        incrementox = -1
    if dx >= dy:
        incrementoyr = 0
        incrementoxr = incrementox
    else:
        incrementoxr = 0
        incrementoyr = incrementoy
        k = dx = dy
    x = x0
    y = y0
    avR = (2 * dy)
    av = (avR - dx)
    avI = (av - dx)
    print (x,y)
    while (x != x1):
        if (av >= 0):
            x = x + incrementox
            y = y + incrementoy
            av = av + avI
        else:
            x = x + incrementoxr
            y = y + incrementoyr
            av = av + avR
        print (x,y)
#================================================================================================
def DDA (x1,y1,x2,y2):
    dx = x2-x1
    dy = y2-y1
    if abs(dx) > abs(dy):
        pasos = abs(dx)
    else:
        pasos = abs(dy)
    xinc = dx/pasos
    yinc = dy/pasos
    x = x1
    y = y1
    print (x1,y1)
    k = 1
    for k in range(pasos):
        x = x + xinc
        y = y + yinc
        print(x,y)
#================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    pantalla.fill(NEGRO)
    print("Bresenham")
    Bresenham(25,15,35,23)
    print("DDA")
    DDA(25,15,35,23)
    pygame.display.flip()
    fin=False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin=True
