import pygame
#====================================================================================================
NEGRO    = (   0,   0,   0)
BLANCO   = ( 255, 255, 255)
AZUL     = (   0,   0, 255)
ROJO     = ( 255,   0,   0)
VERDE    = (   0, 255,   0)
#====================================================================================================
ANCHO = 800
ALTO  = 600
#====================================================================================================
class Jugador(pygame.sprite.Sprite):
    var_x = 0
    var_y = 0
    def __init__(self,an,al):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([an, al])
        self.image.fill(ROJO)
        self.rect = self.image.get_rect()
    def gravedad(self):
        if self.var_y == 0:
            self.var_y = 1
        else:
            self.var_y += .40

        if self.rect.y >= ALTO - self.rect.height and self.var_y >= 0: #Limite Inferior
            self.var_y = 0
            self.rect.y = ALTO - self.rect.height
        if self.rect.x >= ANCHO - self.rect.width and self.var_x >= 0: # Limite  Derecha
            self.var_x = 0
            self.rect.x = ANCHO - self.rect.width
        if self.rect.x < 0:  #Limite Izquierda
            self.rect.x = 0
        if self.rect.y < 0:  #Limite Superior
            self.rect.y = 0
    def update(self):
        self.gravedad()
        self.rect.x+=self.var_x
        lista_colisiones = pygame.sprite.spritecollide(self,lista_plataformas,False)
        for bloque in lista_colisiones:
            if self.var_x > 0:
                self.rect.right = bloque.rect.left  #Lado Derecho del Jugador = Lado Izquierdo del bloque
                print ("impacto")
            if self.rect.right == bloque.rect.left:
                bloque.rect.x +=10
            elif self.var_x < 0:
                self.rect.left = bloque.rect.right  #Lado Izquierdo del Jugador = Lado Derecho del bloque
        self.rect.y+=self.var_y
        lista_colisiones = pygame.sprite.spritecollide(self,lista_plataformas,False)
        for bloque in lista_colisiones:
            if self.var_y > 0:
                self.rect.bottom = bloque.rect.top   #bottom = Inferior; top = superior
            elif self.var_y < 0:
                self.rect.top = bloque.rect.bottom
#====================================================================================================
class Plataforma (pygame.sprite.Sprite):
    def __init__(self,an,al):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([an, al])
        self.image.fill(AZUL)
        self.rect = self.image.get_rect()
#====================================================================================================
class Num_Plataformas(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        Num_plata = [[100,15,200,550],[100,15,300,280]]
        for pl in Num_plata:
            bloque = Plataforma(pl[0],pl[1])
            bloque.rect.x = pl[2]
            bloque.rect.y = pl[3]
            lista_plataformas.add(bloque)
#====================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla = pygame.display.set_mode([ANCHO,ALTO])
    pygame.display.set_caption("Juego basico")
    general = pygame.sprite.Group()
    lista_plataformas = pygame.sprite.Group()
    jp=Jugador(40,60)
    general.add(jp)
    Num_Plataformas()
    fin=False
    reloj=pygame.time.Clock()
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    jp.var_x = -5
                if event.key == pygame.K_RIGHT:
                    jp.var_x=5
                if event.key == pygame.K_UP:
                    jp.var_y = -15
                '''if event.key == pygame.K_DOWN:
                    jp.var_x=0
                    jp.var_y=5'''
            if event.type == pygame.KEYUP:
                jp.var_x = 0
                jp.var_y = 0

        general.update()
        lista_plataformas.update()
        pantalla.fill(NEGRO)
        general.draw(pantalla)
        lista_plataformas.draw(pantalla)
        pygame.display.flip()
        reloj.tick(60)
