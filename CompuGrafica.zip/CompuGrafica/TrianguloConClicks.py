import pygame
from libreriacls import*
#==============================================================================================================
ANCHO =600
ALTO  =600
click = 0
lis = []
#==============================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla = pygame.display.set_mode([ANCHO,ALTO])
    centro = [300,300]
    plano = Plano(ANCHO,ALTO,centro,pantalla)
    pygame.display.flip()
    fin=False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos1 = pygame.mouse.get_pos()
                lis.append(pos1)
                click+=1
                print(Pant_Cart(centro, pos1))
                pygame.display.flip()
            if (click == 3):
                plano.Triangulo(lis)
                print (click)
                pygame.display.flip()
                click = 0
                lis.clear()
            if event.type == pygame.QUIT:
                fin=True
