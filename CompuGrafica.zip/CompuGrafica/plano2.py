import pygame
from libreriacls import *
#===================================================================================================================================
ALTO=600
ANCHO=600
#===================================================================================================================================
def Triangulo9(pln,lsp,p): #pln:plano,lsp:lisa de puntos,p:pantalla
    for p in lsp:
        pln.Punto(p)
    #pygame.draw.line(pantalla,ROJO,pln.Cart(lsp[0]),pln.Cart(lsp[1]))
    pln.Linea(lsp[0],lsp[1])
    pln.Linea(lsp[1],lsp[2])
    pln.Linea(lsp[2],lsp[0])
#===================================================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    pantalla.fill(NEGRO)
    centro=[300,250]
    pl=Plano(ANCHO, ALTO, centro, pantalla) #Objeto plano...Instancia de la clase
    #pl.Punto([30, -30])
    ls=[[10,20],[50,20],[50,100]]
    Triangulo9(pl,ls,pantalla) #dibuja las lineas de ls
    pygame.display.flip()
    fin=False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin=True
