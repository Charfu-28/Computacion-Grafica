import pygame
import random
#================================================================================================================================
ALTO=600
ANCHO=800
ROJO = (255,0,0)
VERDE = (0,255,0)
AZUL = (0,0,255)
BLANCO = (255,255,255)
NEGRO = (0,0,0)
#===============================================================================================================================
class Jugador (pygame.sprite.Sprite):
    def __init__(self ,an, al):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([an, al])
        self.image.fill(ROJO)
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.var_x=0
        self.var_y=0
    def update(self):
        self.rect.x += self.var_x
        self.rect.y += self.var_y
        if self.rect.x>=ANCHO-self.rect.width:
            self.rect.x=ANCHO - self.rect.width
        elif (self.rect.x <= 0):
            self.var_x = 0
#==============================================================================================================================
class Rival (pygame.sprite.Sprite):
    def __init__(self ,an, al):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([an, al])
        self.image.fill(AZUL)
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.rect.y = random.randrange (-100,-50)
        self.var_x=0
        self.var_y=5
        self.temporizador = random.randrange (300)
    def update(self):
        if self.temporizador >= 0:
            self.temporizador -= 2
        else:
            self.rect.y += self.var_y
#==============================================================================================================================
class DivisionPantalla (pygame.sprite.Sprite):
    def __init__(self, an, al):
        pygame.sprite.Sprite.__init__(self)
        self.image=pygame.Surface([an,al])
        self.image.fill(AZUL)
        self.rect = self.image.get_rect()
        self.var_x=0
#==============================================================================================================================
class Vida (pygame.sprite.Sprite):
    def __init__(self, an, al):
        pygame.sprite.Sprite.__init__(self)
        self.image=pygame.Surface([an,al])
        self.image.fill(VERDE)
        self.rect = self.image.get_rect()
        self.var_x=0
        self.var_y=0
#==============================================================================================================================
class Proyectil (pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([5, 20])
        self.image.fill(ROJO)
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
        self.var_y =-5
    def update(self):
        self.rect.y+=self.var_y
#===========================================Main===============================================================================
#===========================================Main===============================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    pantalla.fill(NEGRO)
#============================================Aliados===========================================================================
    Jp = Jugador(60,20)     # creo el Sprite se controlan por grupos
    general = pygame.sprite.Group()
    general.add(Jp)
    Jp.rect.x=370
    Jp.rect.y=520
#===========================================Enemigos===========================================================================
    rivales = pygame.sprite.Group()
    n=10
    for i in range(n):
        r=Rival(20,20)
        r.rect.x = random.randrange(10, ANCHO - 20)
        r.rect.y = -150
        #r.rect.y=random.randrange(10, ALTO - 10)
        rivales.add(r)
        general.add(r)
#==========================================Linea De Division===================================================================
    ln = DivisionPantalla(800,2)
    general.add(ln)
    ln.rect.x = 0
    ln.rect.y = 540
#==========================================Vidas_Puntos========================================================================
    vidas = pygame.sprite.Group()
    vidas1 = pygame.sprite.Group()
    tempx = 120
    tempy = 552
    tempx1 = 750
    tempy1 = 552
    for i in range(3): #Dibuja Los Cuadros de Vida
        life = Vida (50,10)
        life.rect.x = tempx
        life.rect.y = tempy
        tempy += 15
        vidas.add(life)
        general.add(life)
    for i in range(1): #Dibuja Cuadro de Puntos
        point = Vida(40,40)
        point.rect.x = tempx1
        point.rect.y = tempy1
        vidas1.add(point)
        general.add(point)
#==========================================Balas=============================================================================
    balas = pygame.sprite.Group()
#=========================================Gestion de Eventos=================================================================
    ptos = 3
    acu = 0
    fin_juego = False
    reloj = pygame.time.Clock()
    fin=False
    #cicclo del juego
    while not fin:  #Gestion de eventos
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    Jp.var_y=0
                    Jp.var_x=5
                if event.key == pygame.K_LEFT:
                    Jp.var_y=0
                    Jp.var_x=-5
                if event.key == pygame.K_LCTRL:
                    b1 = Proyectil()
                    b1.rect.x = Jp.rect.x + 30
                    b1.rect.y = Jp.rect.y
                    balas.add(b1)
                    general.add(b1)
            if event.type == pygame.KEYUP:  #Evento cuando la tecla se levenata
                Jp.var_y=0
                Jp.var_x=0
            if event.type == pygame.QUIT:
                fin=True
#=============================================================================================================================
        for b in balas:
            ls_col3 = pygame.sprite.spritecollide(b,rivales,True)
            for e in ls_col3:
                acu+=1
                rivales.remove(e)  #Limpiar Memoria
                balas.remove(b)
                general.remove(b)
#=============================================================================================================================
        #Gestion de Colision
        for e in vidas:
            ls_col = pygame.sprite.spritecollide(Jp,rivales, True)   #Colision de Jugador Con rivales
            for elemento in ls_col:
                vidas.remove(e)
                general.remove(e)
                ptos-=1
                print (ptos)
                for i in range(1,2):
                    r=Rival(20,20)
                    r.rect.x=random.randrange(10,ANCHO - 20)
                    r.rect.y=(-150)
                    rivales.add(r)
                    general.add(r)
#=============================================================================================================================
        ls_col2 = pygame.sprite.spritecollide(ln, rivales, True)      #Colision de Rivales Con La Linea
        for elemento in ls_col2:
            for i in range(0,1):
                r=Rival(20,20)
                r.rect.x=random.randrange(10,ANCHO - 20)
                r.rect.y=(-150)
                rivales.add(r)
                general.add(r)
#=============================================================================================================================
        fuente1 = pygame.font.SysFont('Comic Sans MS', 80) #Crea una fuente con tipo y tamaño
        fuente2 = pygame.font.SysFont('Comic Sans MS', 30) #Crea una fuente con tipo y tamaño
#=============================================================================================================================
        if ptos == 0:
            fin_juego = True
        #actualizacion de la pantalla
        if not fin_juego:
            general.update()
            pantalla.fill(NEGRO)
            general.draw(pantalla)
            texto1 = fuente2.render("LIVES: ", True, BLANCO)
            pantalla.blit(texto1,[20,560])
            texto5=fuente2.render(str(ptos), True, BLANCO)
            pantalla.blit(texto5,[95,560])
            texto3 = fuente2.render("POINTS: ", True, BLANCO)
            pantalla.blit(texto3,[650,560])
            texto4=fuente2.render(str(acu), True, NEGRO)
            pantalla.blit(texto4,[755,560])
            texto3 = fuente2.render("LEVEL 1", True, BLANCO)
            pantalla.blit(texto3,[360,560])
            pygame.display.flip()
            reloj.tick(60)
        else:
            texto2 = fuente1.render("GAME OVER", True, BLANCO)
            pantalla.fill(NEGRO)
            pantalla.blit(texto2, [240,280])
            pygame.display.flip()
            reloj.tick(60)
