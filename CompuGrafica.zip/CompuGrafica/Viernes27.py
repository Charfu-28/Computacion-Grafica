import pygame
#====================================================================================================
NEGRO    = (   0,   0,   0)
BLANCO   = ( 255, 255, 255)
AZUL     = (   0,   0, 255)
ROJO     = ( 255,   0,   0)
VERDE    = (   0, 255,   0)
#====================================================================================================
ANCHO = 800
ALTO  = 600
#====================================================================================================
class Jugador(pygame.sprite.Sprite):
    var_x = 0
    var_y = 0
    def __init__(self,m):
        pygame.sprite.Sprite.__init__(self)
        #self.lim = 3
        self.m=m
        self.dir=0
        self.x=0
        self.image = m[self.x+0][self.dir+3]
        self.rect = self.image.get_rect()
    def gravedad(self):
        if self.var_y == 0:
            self.var_y = 1
        else:
            self.var_y += .65
        if self.rect.y >= ALTO - self.rect.height and self.var_y >= 0: #Limite Inferior
            self.var_y = 0
            self.rect.y = ALTO - self.rect.height
        if self.rect.x >= ANCHO - self.rect.width and self.var_x >= 0: # Limite  Derecha
            self.var_x = 0
            self.rect.x = ANCHO - self.rect.width
        if self.rect.x < 0:  #Limite Izquierda
            self.rect.x = 0
        if self.rect.y < 0:  #Limite Superior
            self.rect.y = 0
    def update(self):
        self.gravedad()
        if self.x < 2:
            self.x+=1
        else:
            self.x=0
        self.image = m[self.x+0][self.dir+3]
        self.rect.x+=self.var_x
        lista_colisiones = pygame.sprite.spritecollide(self,lista_plataformas,False)
        for bloque in lista_colisiones:
            if self.var_x > 0:
                self.rect.right = bloque.rect.left
                print ("impacto")
            elif self.var_x < 0:
                self.rect.left = bloque.rect.right
        self.rect.y+=self.var_y
        lista_colisiones = pygame.sprite.spritecollide(self,lista_plataformas,False)
        for bloque in lista_colisiones:
            if self.var_y > 0:
                self.rect.bottom = bloque.rect.top   #bottom = Inferior; top = superior
            elif self.var_y < 0:
                self.rect.top = bloque.rect.bottom
        #if seld.accion ==2:
            #if e.rect.x < self.rect.right:
            #print("ipacto")
            #e.rect.var_x = 2

#====================================================================================================
class Plataforma (pygame.sprite.Sprite):
    def __init__(self,an,al):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([an, al])
        self.image.fill(ROJO)
        self.rect = self.image.get_rect()

    def update(self):
        if self.var.x >0:
            self.var_x = -1
        self.rect.x += self.var_x
#====================================================================================================
class Num_Plataformas(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        Num_plata = [[100,15,200,530],[100,15,300,280]]
        for pl in Num_plata:
            bloque = Plataforma(pl[0],pl[1])
            bloque.rect.x = pl[2]
            bloque.rect.y = pl[3]
            lista_plataformas.add(bloque)
#======================================FUNCION PARA RECORTAR========================================
def matriz (archivo, Cant_x, Cant_y):
    matriz = []
    columna = []
    imagen = pygame.image.load(archivo).convert_alpha()
    ancho_img,alto_img = imagen.get_size()
    factor_y=alto_img/Cant_y
    factor_x=ancho_img/Cant_x
    for i in range (Cant_x):
        columna = []
        for j in range (Cant_y):
            cuadro = (i*factor_x,j*factor_y,70,80)
            recorte = imagen.subsurface(cuadro)
            columna.append(recorte)
        matriz.append(columna)
    return matriz
#====================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla = pygame.display.set_mode([ANCHO,ALTO])
    pygame.display.set_caption("Juego basico")
    m = matriz('ken.png',7,10)
    general = pygame.sprite.Group()
    lista_plataformas = pygame.sprite.Group()
    jp = Jugador(m)
    general.add(jp)
    Num_Plataformas()
    fin=False
    reloj=pygame.time.Clock()
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    jp.var_x = -6
                    jp.var_y = 0
                    jp.dir = 0
                if event.key == pygame.K_RIGHT:
                    jp.var_x = 6
                    jp.var_y = 0
                    jp.dir = 0
                if event.key == pygame.K_DOWN:
                    jp.var_x = 0
                    jp.var_y = 6
                    jp.dir = 0
                if event.key == pygame.K_UP:
                    jp.var_y = -20
                if event.key == pygame.K_SPACE:
                    jp.dir = -1
            if event.type == pygame.KEYUP:
                jp.var_x = 0
                jp.var_y = 0
                jp.dir = 0

        general.update()
        lista_plataformas.update()
        pantalla.fill(NEGRO)
        general.draw(pantalla)
        lista_plataformas.draw(pantalla)
        pygame.display.flip()
        reloj.tick(10)
