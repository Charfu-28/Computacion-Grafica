import pygame

#Contantes globales

# Colores
NEGRO    = (   0,   0,   0)
BLANCO   = ( 255, 255, 255)
AZUL     = (   0,   0, 255)
ROJO     = ( 255,   0,   0)
VERDE    = (   0, 255,   0)

# Dimensiones pantalla
ANCHO = 800
ALTO  = 600

class Jugador(pygame.sprite.Sprite):

    var_x = 0
    var_y = 0
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        ancho = 40
        alto = 60
        self.image = pygame.Surface([ancho, alto])
        self.image.fill(ROJO)
        self.rect = self.image.get_rect()
        self.click = False
        self.pos = [0,0]

    def Mover(self):
        self.var_x = 5

    def update(self):
        self.rect.x+=self.var_x
        self.rect.y+=self.var_y

        if self.click:
            self.rect.center = self.pos

if __name__ == '__main__':
    pygame.init()
    pantalla = pygame.display.set_mode([ANCHO,ALTO])
    pygame.display.set_caption("Juego basico")

    #Grupos
    general=pygame.sprite.Group()

    jp=Jugador()
    general.add(jp)


    fin=False
    reloj=pygame.time.Clock()
    while not fin:
        pos = pygame.mouse.get_pos()
        jp.pos = pos
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin = True

            if event.type == pygame.MOUSEBUTTONDOWN:
                #pos = pygame.mouse.get_pos()
                #jp.Posicion(pygame.mouse.get_pos())
                if jp.rect.collidepoint(pos):
                    #jp.Posicion(pos)
                    jp.click = True
                    jp.Mover()
                    #jp.Posicion(pos)
            if event.type == pygame.MOUSEBUTTONUP:
                jp.click = False



                '''if event.key == pygame.K_LEFT:
                    jp.var_x=-5
                    jp.var_y=0
                if event.key == pygame.K_RIGHT:
                    jp.var_x=5
                    jp.var_y=0
                if event.key == pygame.K_UP:
                    jp.var_x=0
                    jp.var_y=-5
                if event.key == pygame.K_DOWN:
                    jp.var_x=0
                    jp.var_y=5'''
        general.update()
        pantalla.fill(NEGRO)
        general.draw(pantalla)
        pygame.display.flip()
        reloj.tick(60)


        # Hacer llegar al correo  platilla del documento de Diseño
        
