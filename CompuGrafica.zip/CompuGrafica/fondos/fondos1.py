import pygame
from numpy import *
#*************************************************************************************************************************
ALTO  = 480
ANCHO = 640
sp_fil = 12
sp_col = 32
#*************************************************************************************************************************
def Recorte(an,al):
    matriz = []
    for i in range(an):
        matriz.append([])
        for j in range(al):
            cuadro = ((i*32),(j*32), 32,32)
            matriz[i].append(imagen.subsurface(cuadro))
    return matriz
#*************************************************************************************************************************
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    imagen = pygame.image.load('terrenogen.png').convert()
    ancho_img, alto_imag =  imagen.get_size()
    print ('ancho: ',ancho_img, 'ALTO: ',alto_imag)
    m = Recorte(sp_col,sp_fil)
    pantalla.blit (m[6][1],[0,0])
    pygame.display.flip()
    fin=False
    while not fin:
        #Gestion de eventos
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin=True
