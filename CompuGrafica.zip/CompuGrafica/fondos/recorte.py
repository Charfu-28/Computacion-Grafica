import pygame
import random
#================================================================================================================================
ALTO=600
ANCHO=800
ROJO = (255,0,0)
VERDE = (0,255,0)
AZUL = (0,0,255)
BLANCO = (255,255,255)
NEGRO = (0,0,0)
sp_fil = 12
sp_col = 32
#===============================================================================================================================
def Recorte(an,al):
    imagen = pygame.image.load('terrenogen.png').convert()
    ancho_img, alto_imag =  imagen.get_size()
    matriz = []
    for i in range(an):
        matriz.append([])
        for j in range(al):
            cuadro = ((i*32),(j*32), 32,32)
            matriz[i].append(imagen.subsurface(cuadro))
    return matriz
#===========================================Main===============================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    pantalla.fill(NEGRO)
    m = Recorte(sp_col,sp_fil)
    i=31
    j=11
    var_x = 0
    var_y = 0
    x=0
    y=0
    pantalla.blit(m[i][j],[x,y])
    pygame.display.flip()
    fin=False
    #cicclo del juego
    while not fin:  #Gestion de eventos
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    var_x = 0
                    var_y-=5
                    y+=var_y
                if event.key == pygame.K_DOWN:
                    var_x = 0
                    var_y+=5
                    y+=var_y
                if event.key == pygame.K_RIGHT:
                    var_x+=5
                    var_y = 0
                    x+=var_x
                if event.key == pygame.K_LEFT:
                    var_x-=5
                    var_y = 0
                    x+=var_x
            if event.type == pygame.KEYUP:  #Evento cuando la tecla se levenata
                var_y=0
                var_x=0
            if event.type == pygame.QUIT:
                fin=True
        pantalla.fill(NEGRO)
        pantalla.blit (m[i][j],[x,y])
        pygame.display.flip()
