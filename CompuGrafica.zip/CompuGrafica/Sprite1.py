import pygame

#===================================================================================================================================
ALTO=600
ANCHO=800
ROJO = (255,0,0)
VERDE = (0,255,0)
AZUL = (0,0,255)
BLANCO = (255,255,255)
NEGRO = (0,0,0)
#===================================================================================================================================
class Bloque (pygame.sprite.Sprite):
    def __init__(self ,an, al):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([an, al])
        self.image.fill(ROJO)
        self.rect = self.image.get_rect() #almacena informacion alto y ancho y posicion
#===================================================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    bl = Bloque(50,70)  # creo el Sprite se controlan por grupos
    general = pygame.sprite.Group()
    general.add(bl)
    bl.rect.x=100
    bl.rect.y=100
    reloj = pygame.time.Clock()
    #general.draw(pantalla)
    #pygame.display.flip()
    fin=False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin=True
        bl.rect.x+=5
        bl.rect.y+=5
        #actualizacion de la pantalla
        pantalla.fill(NEGRO)
        general.draw(pantalla)
        pygame.display.flip()
        reloj.tick(60)
