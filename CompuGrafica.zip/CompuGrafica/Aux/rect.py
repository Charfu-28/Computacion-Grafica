import pygame

ALTO = 400
ANCHO = 600
ROJO = (255,0,0)
BLANCO = (255,255,255)

def mover (pantalla, rect):
	pygame.draw.rect(pantalla, ROJO, rect)
	fin = False
	while not False:
		for event in pygame.event.get():
			if event.type == pygame.MOUSEBUTTONDOWN:
				pos=pygame.mouse.get_pressed()
				if pos[0]==1:
					rect[0]+=10
					rect[1]+10
					pantalla.fill(BLANCO)
					pygame.draw.rect(pantalla, ROJO, rect)
					pygame.display(flip)
			if event.type == pygame.QUIT:
				fin = True





if __name__ == '__main__':
    pygame.init()
    pantalla = pygame.display.set_mode([ANCHO, ALTO])
    pantalla.fill(BLANCO)
    rect = (50,50,50,50)
    #rect = rect.move(10,10)
    mover(pantalla, rect)
    #pygame.draw.rect(pantalla, ROJO, rect)
    pygame.display.flip()
    fin = False
    while not fin:
        #pos = pygame.mouse.get_pos()
        pygame.display.flip()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
            	fin = True