import pygame
from libreriaob import*

ALTO = 400
ANCHO = 600

def triangulo (pln, ls):
    for p in ls:
        pln.Punto(p)

if __name__ == '__main__':
    pygame.init()
    pantalla = pygame.display.set_mode([ANCHO, ALTO])
    pantalla.fill(BLANCO)
    centro = [200,250]
    pl=Plano(ANCHO,ALTO, centro,pantalla)
    punto_movil(pl, [2,2])
    #clicks(pl)
    ls = [[100,100],[150,100],[125, 150]]
    #mover_teclas(pl,ls)
    #pygame.MOUSSEMOTION detecta movimiento del mouse
    #pl.ejes()
    ls = [[100,100],[150,100],[125, 150]]
    '''pl.triangulo(ls)
    ld=rotacionPuntoFijo(ls,90, [150,150])
    pl.triangulo(ld)
    lx=rotacion(ls,90)
    pl.triangulo(lx)'''

    pygame.display.flip()
    fin = False
    while not fin:
        pos=0

        pos2=0
        list_pos=[]
        clicks = 0
        for event in pygame.event.get():
            '''if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                list_pos.append(pos)
                clicks+=1
                if (clicks==2):
                    pl.Linea(list_pos[0], list_pos[1])
                    list_pos.clear


            if event.type == pygame.MOUSEBUTTONDOWN:
                pos2 = pygame.mouse.get_pos()
                pl.Linea(pos, pos2)
                pygame.display.flip()'''

            if event.type == pygame.QUIT:
                fin=True
