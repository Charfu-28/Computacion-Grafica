import pygame
from libreriacls import*
#===========================================================================================================
ALTO = 600
ANCHO = 600
#===========================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla = pygame.display.set_mode([ANCHO, ALTO])
    pantalla.fill(NEGRO)
    centro = [200,400]
    pl = Plano(ANCHO,ALTO, centro,pantalla)
    ls = [[50,50],[100,50],[75,100]]
    MoverConTeclas(pl,ls)
    pygame.display.flip()
    fin = False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin=True
