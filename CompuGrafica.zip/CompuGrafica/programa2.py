ls=[1,3,'hola',True]
'''
for e in ls:
    print e
'''
limite =len(ls)
print ('limite de la lista:',limite)
for i in range(limite):
    print (ls[i])
'''
for i in range(2,10,2):
    print i
'''
