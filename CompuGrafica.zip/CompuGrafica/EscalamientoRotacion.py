import pygame
from libreriacls import *
#=======================================================================================================================
ALTO=600
ANCHO=600
#=======================================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    pantalla.fill(NEGRO)
    centro=[200,400]
    pl=Plano(ANCHO, ALTO, centro, pantalla) #Objeto plano...Instancia de la clase
    ls = [[90,90],[150,90],[90,180]]
    pl.Linea2([30,30],[150,30])
    #Escalamieto linea
    p1=Escalamiento([2,2],[30,30])
    p2=Escalamiento([2,2],[150,30])
    pl.Linea(p1,p2)
    #rotacion linea
    p2= Rotacion(p2,90)
    p1= Rotacion(p1,90)
    pl.Linea(p1,p2)
    #Escalamiento Linea punto Fijo
    p1=EscalamientoPuntoFijo([30,30],[30,30],[2,2])
    p2=EscalamientoPuntoFijo([150,30],[30,30],[2,2])
    pl.Linea(p1,p2)
    #Rotacion Respecto a un punto Fijo
    pl.Triangulo(ls)
    ls = RotacionPuntoFijo(ls,180,[90,90])
    pl.Triangulo(ls)
    #pl.Punto([30, -30])
    #Triangulo(pl,ls,pantalla) #dibuja las lineas de ls
    pygame.display.flip()
    fin=False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin=True
