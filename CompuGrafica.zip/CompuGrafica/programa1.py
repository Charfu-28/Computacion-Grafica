def Mostrar(lista):
    i=0
    while i<len(lista):
        print (lista[i])
        i+=1

ls = [1,2.4,'hola',[2,6,8],True]
Mostrar(ls)
