import pygame

ALTO=400
ANCHO=600
ROJO=(255,0,0)
BLANCO=(0,0,0)
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    #pygame.display.flip()
    vary=100 #variable que cambia la posicion
    reloj=pygame.time.Clock()
    fin=False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin=True
        #Codigo del programa
        pantalla.fill(BLANCO)
        #print vary
        pygame.draw.line(pantalla, (ROJO),[100,100],[200,vary],2)
        pygame.display.flip()
        vary+=10
        reloj.tick(20)
