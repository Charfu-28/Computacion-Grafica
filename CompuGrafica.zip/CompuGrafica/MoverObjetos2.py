import pygame
pygame.init()
size = 800, 600
ladoX = 400
ladoY = 300

mousePos = pygame.mouse.get_pos()
screen = pygame.display.set_mode(size)

while 1:
    mousex,mousey = pygame.mouse.get_pos()
    print (mousex,mousey)
    for event in pygame.event.get():
        #print (event)
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                ladoX = ladoX - 4
            if event.key == pygame.K_RIGHT:
                ladoX = ladoX + 4
            if event.key == pygame.K_UP:
                ladoY = ladoY - 4
            if event.key == pygame.K_DOWN:
                ladoY = ladoY + 4

    screen.fill((0,0,0))
    pygame.draw.rect(screen,(255,0,0),(ladoX,ladoY,80,80))
    pygame.draw.rect(screen,(0,255,0),(mousex,mousey,80,80))
    pygame.display.update()
