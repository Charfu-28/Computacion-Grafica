import pygame
from libreriacls import*
#==============================================================================================================
ANCHO =600
ALTO  =600
#==============================================================================================================
def triangulo (pan):
    click = 0
    lis = []
    fin = False
    while not fin:
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos1 = pygame.mouse.get_pos()
                lis.append(pos1)
                punto1 = Pant_Cart(pan.centro, pos1)
                print(punto1)
                pan.Punto(punto1)
                click+=1
            if click ==2:
                pos2 = pygame.mouse.get_pos()
                lis.append(pos2)
                punto2 = Pant_Cart(pan.centro, pos2)
                print(punto2)
                pan.Punto(punto2)
#==============================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    centro = [300,300]
    plano = Plano(ANCHO,ALTO,centro,pantalla)
    triangulo(plano)
    pygame.display.flip()
    fin=False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin=True
