import pygame
import math
from libreriacls import *
#===================================================================================================================================
ALTO=600
ANCHO=600
#===================================================================================================================================
if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    pantalla.fill(NEGRO)
    centro =[300,300]
    plano = Polar(ANCHO,ALTO,centro,pantalla)
    #plano.Punto(50,45)
    #plano.Linea([40,-50],[-50,-10])  Recta Normal
    r=0
    t=0
    '''for t in range(361):
        nt = math.radians(t)
        r = 100 * math.cos(3*nt)
        plano.Punto(r,t)
        plano.Recta(r,t)
    '''
    reloj = pygame.time.Clock()
    #plano.Recta(50,45)  #Recta Polar
    pygame.display.flip()
    fin=False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin=True
        #pantalla.fill(NEGRO)  Animacion linea
        plano.Ecuacion(t)
        pygame.display.flip()
        reloj.tick(60)
        if t <= 360:
            t+=1
