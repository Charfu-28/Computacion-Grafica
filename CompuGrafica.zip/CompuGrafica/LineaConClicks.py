import pygame
from libreriacls import*
ANCHO =600
ALTO  =600
def clicks (pantalla):
    clicks = 0
    list_p = []
    print("entre")
    fin = False
    while not fin:
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                list_p.append(pos)
                clicks+=1
                print(Pant(pantalla.centro, pos))
            if(clicks==2):
                pantalla.Linea(list_p[0],list_p[1])
                m = (list_p[1][1]-list_p[0][1])/(list_p[1][0]-list_p[0][0])
                corte = (m*list_p[0][0])+list_p[0][1]
                print("La ecuacion de la recta es y={:.2F}x+{:.2F}".format(m,corte))
                clicks=0
                list_p.clear()
            if event.type == pygame.QUIT:
                    fin=True
def Pant(centro,pto):
        px = pto[0]-centro[0]
        py = centro[1]-pto[1]
        return[px,py]

if __name__ == '__main__':
    pygame.init()
    pantalla=pygame.display.set_mode([ANCHO,ALTO])
    centro = [300,300]
    plano = Plano(ANCHO,ALTO,centro,pantalla)
    clicks(plano)
    pygame.display.flip()
    fin=False
    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin=True
